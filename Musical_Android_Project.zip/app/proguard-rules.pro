-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* <methods>;
}
-keep class com.musical.app.domain.model.** { *; }
-keep class com.musical.app.data.local.db.entity.** { *; }
