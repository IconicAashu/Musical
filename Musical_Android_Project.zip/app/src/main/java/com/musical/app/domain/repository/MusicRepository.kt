package com.musical.app.domain.repository

import com.musical.app.domain.model.LrcLine
import com.musical.app.domain.model.Playlist
import com.musical.app.domain.model.Track
import kotlinx.coroutines.flow.Flow

interface MusicRepository {
    val tracksFlow: Flow<List<Track>>
    val favouriteTracksFlow: Flow<List<Track>>
    val recentlyPlayedFlow: Flow<List<Track>>
    val playlistsFlow: Flow<List<Playlist>>
    val isAmoledThemeFlow: Flow<Boolean>

    suspend fun scanDeviceMusic(): List<Track>
    suspend fun toggleFavourite(trackId: Long)
    suspend fun recordRecentPlay(trackId: Long)
    suspend fun createPlaylist(name: String, description: String): Long
    suspend fun renamePlaylist(playlistId: Long, newName: String, newDescription: String)
    suspend fun deletePlaylist(playlistId: Long)
    suspend fun addTrackToPlaylist(playlistId: Long, trackId: Long)
    suspend fun removeTrackFromPlaylist(playlistId: Long, trackId: Long)
    suspend fun loadLyricsForTrack(track: Track): List<LrcLine>
    suspend fun saveCustomLyricsForTrack(trackId: Long, rawLrcContent: String): List<LrcLine>
    suspend fun setAmoledTheme(enabled: Boolean)
}
