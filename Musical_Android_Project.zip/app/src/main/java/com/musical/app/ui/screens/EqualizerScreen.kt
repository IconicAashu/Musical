package com.musical.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.musical.app.domain.model.EqualizerState
import com.musical.app.ui.theme.AmoledBlack
import com.musical.app.ui.theme.EmeraldBright
import com.musical.app.ui.theme.EmeraldPrimary
import com.musical.app.ui.theme.TextPrimary
import com.musical.app.ui.theme.TextSecondary

@Composable
fun EqualizerScreen(
    equalizerState: EqualizerState,
    onBack: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
    onSelectPreset: (Int) -> Unit,
    onBandLevelChanged: (Int, Int) -> Unit,
    onBassBoostChanged: (Int) -> Unit,
    onVirtualizerChanged: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        // Header with Master Enable Switch
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Column {
                    Text(
                        text = "Audio Equalizer & DSP",
                        style = MaterialTheme.typography.headlineSmall,
                        color = TextPrimary
                    )
                    Text(
                        text = if (equalizerState.enabled) "Hardware AudioEffect Active" else "Bypassed (Flat Output)",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (equalizerState.enabled) EmeraldPrimary else TextSecondary
                    )
                }
            }

            Switch(
                checked = equalizerState.enabled,
                onCheckedChange = onToggleEnabled,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = AmoledBlack,
                    checkedTrackColor = EmeraldPrimary
                )
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Real-Time Frequency Response Curve Canvas
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(16.dp)
        ) {
            val bands = equalizerState.bands
            if (bands.isNotEmpty()) {
                val width = size.width
                val height = size.height
                val midY = height / 2f

                // 0 dB center reference line
                drawLine(
                    color = TextSecondary.copy(alpha = 0.25f),
                    start = Offset(0f, midY),
                    end = Offset(width, midY),
                    strokeWidth = 2f
                )

                val points = bands.mapIndexed { idx, band ->
                    val x = if (bands.size > 1) {
                        (idx.toFloat() / (bands.size - 1).toFloat()) * width
                    } else width / 2f
                    val span = (band.maxLevelMb - band.minLevelMb).coerceAtLeast(1)
                    val normalized = (band.currentLevelMb - band.minLevelMb).toFloat() / span.toFloat()
                    val y = height - (normalized * height)
                    Offset(x, y)
                }

                val curvePath = Path().apply {
                    moveTo(points.first().x, points.first().y)
                    for (i in 0 until points.lastIndex) {
                        val current = points[i]
                        val next = points[i + 1]
                        val controlX = (current.x + next.x) / 2f
                        cubicTo(controlX, current.y, controlX, next.y, next.x, next.y)
                    }
                }

                val fillPath = Path().apply {
                    addPath(curvePath)
                    lineTo(points.last().x, height)
                    lineTo(points.first().x, height)
                    close()
                }

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            EmeraldPrimary.copy(alpha = 0.40f),
                            EmeraldPrimary.copy(alpha = 0.0f)
                        )
                    )
                )

                drawPath(
                    path = curvePath,
                    color = EmeraldBright,
                    style = Stroke(width = 4.dp.toPx())
                )

                points.forEach { pt ->
                    drawCircle(
                        color = EmeraldPrimary,
                        radius = 6.dp.toPx(),
                        center = pt
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Preset Selector Chips
        Text(
            text = "Acoustic Presets",
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            itemsIndexed(equalizerState.presetNames) { index, name ->
                val selected = equalizerState.selectedPresetIndex == index
                FilterChip(
                    selected = selected,
                    onClick = { onSelectPreset(index) },
                    label = {
                        Text(
                            text = name,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldPrimary,
                        selectedLabelColor = AmoledBlack,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        labelColor = TextPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Individual Frequency Band Sliders
        Text(
            text = "Frequency Bands",
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))

        equalizerState.bands.forEach { band ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = band.formattedFrequency,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "%+.1f dB".format(band.currentDb),
                        style = MaterialTheme.typography.labelLarge,
                        color = EmeraldPrimary
                    )
                }
                Slider(
                    value = band.currentLevelMb.toFloat(),
                    onValueChange = { newMb -> onBandLevelChanged(band.index, newMb.toInt()) },
                    valueRange = band.minLevelMb.toFloat()..band.maxLevelMb.toFloat(),
                    enabled = equalizerState.enabled,
                    colors = SliderDefaults.colors(
                        thumbColor = EmeraldPrimary,
                        activeTrackColor = EmeraldPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Bass Boost & 3D Virtualizer Controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(14.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Sub-Bass Boost", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                Text("${equalizerState.bassBoostStrength / 10}%", color = EmeraldPrimary)
            }
            Slider(
                value = equalizerState.bassBoostStrength.toFloat(),
                onValueChange = { onBassBoostChanged(it.toInt()) },
                valueRange = 0f..1000f,
                enabled = equalizerState.enabled,
                colors = SliderDefaults.colors(
                    thumbColor = EmeraldPrimary,
                    activeTrackColor = EmeraldPrimary
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("3D Stereo Virtualizer", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                Text("${equalizerState.virtualizerStrength / 10}%", color = EmeraldPrimary)
            }
            Slider(
                value = equalizerState.virtualizerStrength.toFloat(),
                onValueChange = { onVirtualizerChanged(it.toInt()) },
                valueRange = 0f..1000f,
                enabled = equalizerState.enabled,
                colors = SliderDefaults.colors(
                    thumbColor = EmeraldPrimary,
                    activeTrackColor = EmeraldPrimary
                )
            )
        }

        Spacer(modifier = Modifier.height(80.dp))
    }
}
