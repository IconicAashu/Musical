package com.musical.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.musical.app.domain.model.PlaybackState
import com.musical.app.domain.model.RepeatMode
import com.musical.app.domain.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PlaybackController(
    private val context: Context,
    private val scope: CoroutineScope,
    val equalizerController: AudioEqualizerController,
    private val onTrackPlayed: (Long) -> Unit
) {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private var progressPollingJob: Job? = null

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    val sleepTimerManager = SleepTimerManager(
        scope = scope,
        onTimerExpired = { pause() }
    )

    private val trackLookup = mutableMapOf<Long, Track>()

    init {
        connectSession()
        scope.launch {
            sleepTimerManager.remainingMs.collect { remaining ->
                _playbackState.update { it.copy(sleepTimerRemainingMs = remaining) }
            }
        }
        scope.launch {
            sleepTimerManager.stopAtEndOfTrack.collect { stopAtEnd ->
                _playbackState.update { it.copy(stopAtEndOfTrack = stopAtEnd) }
            }
        }
    }

    private fun connectSession() {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, MusicalPlaybackService::class.java)
        )
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                val controller = runCatching { future.get() }.getOrNull() ?: return@addListener
                mediaController = controller
                attachPlayerListener(controller)
                syncStateFromController(controller)
            },
            MoreExecutors.directExecutor()
        )
    }

    private fun attachPlayerListener(controller: MediaController) {
        controller.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                syncStateFromController(controller)
                if (isPlaying) startProgressPolling() else stopProgressPolling()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                    sleepTimerManager.onTrackTransitioned()
                }
                syncStateFromController(controller)
                mediaItem?.mediaId?.toLongOrNull()?.let { trackId ->
                    onTrackPlayed(trackId)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                syncStateFromController(controller)
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                syncStateFromController(controller)
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                syncStateFromController(controller)
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId != C.AUDIO_SESSION_ID_UNSET && audioSessionId > 0) {
                    equalizerController.bindToAudioSession(audioSessionId)
                    _playbackState.update { it.copy(audioSessionId = audioSessionId) }
                }
            }
        })
    }

    private fun syncStateFromController(controller: MediaController) {
        val queueTracks = (0 until controller.mediaItemCount).mapNotNull { idx ->
            val itemId = controller.getMediaItemAt(idx).mediaId.toLongOrNull()
            itemId?.let { trackLookup[it] }
        }
        val currentIdx = controller.currentMediaItemIndex
        val currentTrack = controller.currentMediaItem?.mediaId?.toLongOrNull()?.let { trackLookup[it] }
            ?: queueTracks.getOrNull(currentIdx)

        val duration = controller.duration.takeIf { it > 0 } ?: currentTrack?.durationMs ?: 0L
        val position = controller.currentPosition.coerceIn(0L, duration.coerceAtLeast(0L))

        val mappedRepeat = when (controller.repeatMode) {
            Player.REPEAT_MODE_ALL -> RepeatMode.ALL
            Player.REPEAT_MODE_ONE -> RepeatMode.ONE
            else -> RepeatMode.OFF
        }

        _playbackState.update { state ->
            state.copy(
                currentTrack = currentTrack,
                isPlaying = controller.isPlaying,
                positionMs = position,
                durationMs = duration,
                shuffleEnabled = controller.shuffleModeEnabled,
                repeatMode = mappedRepeat,
                queue = if (queueTracks.isNotEmpty()) queueTracks else state.queue,
                currentQueueIndex = currentIdx
            )
        }
    }

    private fun startProgressPolling() {
        progressPollingJob?.cancel()
        progressPollingJob = scope.launch {
            while (true) {
                val controller = mediaController
                if (controller != null && controller.isPlaying) {
                    val duration = controller.duration.takeIf { it > 0 }
                        ?: _playbackState.value.currentTrack?.durationMs
                        ?: 0L
                    val pos = controller.currentPosition.coerceIn(0L, duration.coerceAtLeast(0L))
                    _playbackState.update { it.copy(positionMs = pos, durationMs = duration) }
                }
                delay(100L)
            }
        }
    }

    private fun stopProgressPolling() {
        progressPollingJob?.cancel()
        progressPollingJob = null
    }

    fun registerTracks(tracks: List<Track>) {
        tracks.forEach { trackLookup[it.id] = it }
        // Refresh currentTrack / queue favourite status if changed
        _playbackState.update { current ->
            val updatedCurrent = current.currentTrack?.let { trackLookup[it.id] ?: it }
            val updatedQueue = current.queue.map { trackLookup[it.id] ?: it }
            current.copy(currentTrack = updatedCurrent, queue = updatedQueue)
        }
    }

    fun playTracks(tracks: List<Track>, startIndex: Int = 0) {
        if (tracks.isEmpty()) return
        registerTracks(tracks)
        val safeIndex = startIndex.coerceIn(0, tracks.lastIndex)
        val selectedTrack = tracks[safeIndex]

        // Immediately update UI state even before async controller completes
        _playbackState.update {
            it.copy(
                currentTrack = selectedTrack,
                queue = tracks,
                currentQueueIndex = safeIndex,
                positionMs = 0L,
                durationMs = selectedTrack.durationMs,
                isPlaying = true
            )
        }
        onTrackPlayed(selectedTrack.id)

        val controller = mediaController ?: return
        val mediaItems = tracks.map { it.toMediaItem() }
        controller.setMediaItems(mediaItems, safeIndex, 0L)
        controller.prepare()
        controller.play()
    }

    fun togglePlayPause() {
        val controller = mediaController
        if (controller == null) {
            _playbackState.update { it.copy(isPlaying = !it.isPlaying) }
            return
        }
        if (controller.isPlaying) {
            controller.pause()
        } else {
            if (controller.playbackState == Player.STATE_IDLE || controller.mediaItemCount == 0) {
                val queue = _playbackState.value.queue
                val idx = _playbackState.value.currentQueueIndex.coerceAtLeast(0)
                if (queue.isNotEmpty()) {
                    playTracks(queue, idx)
                    return
                }
            }
            controller.play()
        }
    }

    fun pause() {
        mediaController?.pause()
        _playbackState.update { it.copy(isPlaying = false) }
    }

    fun seekTo(positionMs: Long) {
        val duration = _playbackState.value.durationMs
        val clamped = positionMs.coerceIn(0L, duration.coerceAtLeast(0L))
        mediaController?.seekTo(clamped)
        _playbackState.update { it.copy(positionMs = clamped) }
    }

    fun skipNext() {
        val controller = mediaController
        if (controller != null && controller.hasNextMediaItem()) {
            controller.seekToNextMediaItem()
        } else {
            val state = _playbackState.value
            if (state.queue.isNotEmpty()) {
                val nextIdx = (state.currentQueueIndex + 1) % state.queue.size
                playTracks(state.queue, nextIdx)
            }
        }
    }

    fun skipPrevious() {
        val controller = mediaController
        if (controller != null) {
            if (controller.currentPosition > 3_500L) {
                controller.seekTo(0L)
            } else if (controller.hasPreviousMediaItem()) {
                controller.seekToPreviousMediaItem()
            } else {
                controller.seekTo(0L)
            }
        } else {
            val state = _playbackState.value
            if (state.queue.isNotEmpty()) {
                val prevIdx = if (state.currentQueueIndex > 0) state.currentQueueIndex - 1 else state.queue.lastIndex
                playTracks(state.queue, prevIdx)
            }
        }
    }

    fun toggleShuffle() {
        val nextShuffle = !_playbackState.value.shuffleEnabled
        mediaController?.shuffleModeEnabled = nextShuffle
        _playbackState.update { it.copy(shuffleEnabled = nextShuffle) }
    }

    fun cycleRepeatMode() {
        val nextMode = when (_playbackState.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        val playerMode = when (nextMode) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
        }
        mediaController?.repeatMode = playerMode
        _playbackState.update { it.copy(repeatMode = nextMode) }
    }

    fun addToQueue(track: Track) {
        registerTracks(listOf(track))
        val currentQueue = _playbackState.value.queue.toMutableList()
        if (currentQueue.isEmpty()) {
            playTracks(listOf(track), 0)
            return
        }
        currentQueue.add(track)
        mediaController?.addMediaItem(track.toMediaItem())
        _playbackState.update { it.copy(queue = currentQueue) }
    }

    fun playNextInQueue(track: Track) {
        registerTracks(listOf(track))
        val state = _playbackState.value
        if (state.queue.isEmpty()) {
            playTracks(listOf(track), 0)
            return
        }
        val insertIndex = (state.currentQueueIndex + 1).coerceIn(0, state.queue.size)
        val updatedQueue = state.queue.toMutableList().apply { add(insertIndex, track) }
        mediaController?.addMediaItem(insertIndex, track.toMediaItem())
        _playbackState.update { it.copy(queue = updatedQueue) }
    }

    fun removeFromQueue(index: Int) {
        val state = _playbackState.value
        if (index !in state.queue.indices) return
        val updatedQueue = state.queue.toMutableList().apply { removeAt(index) }
        mediaController?.removeMediaItem(index)
        val newCurrentIdx = when {
            updatedQueue.isEmpty() -> -1
            index < state.currentQueueIndex -> state.currentQueueIndex - 1
            index == state.currentQueueIndex -> state.currentQueueIndex.coerceAtMost(updatedQueue.lastIndex)
            else -> state.currentQueueIndex
        }
        _playbackState.update {
            it.copy(
                queue = updatedQueue,
                currentQueueIndex = newCurrentIdx,
                currentTrack = updatedQueue.getOrNull(newCurrentIdx)
            )
        }
    }

    fun moveQueueItem(fromIndex: Int, toIndex: Int) {
        val state = _playbackState.value
        if (fromIndex !in state.queue.indices || toIndex !in state.queue.indices || fromIndex == toIndex) return
        val updatedQueue = state.queue.toMutableList()
        val moved = updatedQueue.removeAt(fromIndex)
        updatedQueue.add(toIndex, moved)
        mediaController?.moveMediaItem(fromIndex, toIndex)

        val currentTrackId = state.currentTrack?.id
        val newCurrentIdx = updatedQueue.indexOfFirst { it.id == currentTrackId }
        _playbackState.update {
            it.copy(queue = updatedQueue, currentQueueIndex = newCurrentIdx)
        }
    }

    fun clearQueue() {
        mediaController?.stop()
        mediaController?.clearMediaItems()
        _playbackState.update {
            it.copy(
                currentTrack = null,
                isPlaying = false,
                positionMs = 0L,
                durationMs = 0L,
                queue = emptyList(),
                currentQueueIndex = -1
            )
        }
    }

    fun release() {
        stopProgressPolling()
        sleepTimerManager.cancelTimer()
        equalizerController.releaseEffects()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        mediaController = null
    }

    private fun Track.toMediaItem(): MediaItem {
        val metadataBuilder = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setTrackNumber(trackNumber)
        albumArtUri?.let { art ->
            metadataBuilder.setArtworkUri(Uri.parse(art))
        }
        val requestMetadata = MediaItem.RequestMetadata.Builder()
            .setMediaUri(Uri.parse(uri))
            .build()
        return MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(Uri.parse(uri))
            .setRequestMetadata(requestMetadata)
            .setMediaMetadata(metadataBuilder.build())
            .build()
    }
}
