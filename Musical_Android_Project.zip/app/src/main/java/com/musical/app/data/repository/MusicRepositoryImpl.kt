package com.musical.app.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.musical.app.data.local.db.dao.MusicDao
import com.musical.app.data.local.db.entity.CachedTrackEntity
import com.musical.app.data.local.db.entity.CustomLrcEntity
import com.musical.app.data.local.db.entity.FavouriteTrackEntity
import com.musical.app.data.local.db.entity.PlaylistEntity
import com.musical.app.data.local.db.entity.PlaylistTrackCrossRef
import com.musical.app.data.local.db.entity.RecentPlayEntity
import com.musical.app.data.local.scanner.LocalAudioScanner
import com.musical.app.data.local.scanner.LrcParser
import com.musical.app.domain.model.LrcLine
import com.musical.app.domain.model.Playlist
import com.musical.app.domain.model.Track
import com.musical.app.domain.repository.MusicRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext
import java.io.File

class MusicRepositoryImpl(
    private val context: Context,
    private val musicDao: MusicDao,
    private val localAudioScanner: LocalAudioScanner
) : MusicRepository {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("musical_prefs", Context.MODE_PRIVATE)

    private val _isAmoledThemeFlow = MutableStateFlow(prefs.getBoolean(KEY_AMOLED_THEME, true))
    override val isAmoledThemeFlow: Flow<Boolean> = _isAmoledThemeFlow.asStateFlow()

    override val tracksFlow: Flow<List<Track>> = combine(
        musicDao.observeCachedTracks(),
        musicDao.observeFavourites()
    ) { cachedEntities, favEntities ->
        val favIds = favEntities.map { it.trackId }.toSet()
        cachedEntities.map { entity ->
            entity.toDomain(isFavourite = favIds.contains(entity.id))
        }
    }

    override val favouriteTracksFlow: Flow<List<Track>> = combine(
        tracksFlow,
        musicDao.observeFavourites()
    ) { allTracks, favEntities ->
        val trackById = allTracks.associateBy { it.id }
        favEntities.mapNotNull { fav -> trackById[fav.trackId] }
    }

    override val recentlyPlayedFlow: Flow<List<Track>> = combine(
        tracksFlow,
        musicDao.observeRecentPlays()
    ) { allTracks, recentEntities ->
        val trackById = allTracks.associateBy { it.id }
        recentEntities.mapNotNull { recent -> trackById[recent.trackId] }
    }

    override val playlistsFlow: Flow<List<Playlist>> = combine(
        tracksFlow,
        musicDao.observePlaylists(),
        musicDao.observeAllPlaylistTrackRefs()
    ) { allTracks, playlistEntities, crossRefs ->
        val trackById = allTracks.associateBy { it.id }
        val refsByPlaylist = crossRefs.groupBy { it.playlistId }
        playlistEntities.map { entity ->
            val orderedTracks = refsByPlaylist[entity.id]
                .orEmpty()
                .sortedBy { it.positionOrder }
                .mapNotNull { ref -> trackById[ref.trackId] }
            Playlist(
                id = entity.id,
                name = entity.name,
                description = entity.description,
                createdAtMs = entity.createdAtMs,
                tracks = orderedTracks
            )
        }
    }

    override suspend fun scanDeviceMusic(): List<Track> = withContext(Dispatchers.IO) {
        val scanned = localAudioScanner.scanLocalAudioFiles()
        if (scanned.isNotEmpty()) {
            musicDao.upsertCachedTracks(scanned.map { CachedTrackEntity.fromDomain(it) })
        }
        scanned
    }

    override suspend fun toggleFavourite(trackId: Long) = withContext(Dispatchers.IO) {
        val exists = musicDao.isFavourite(trackId)
        if (exists) {
            musicDao.deleteFavourite(trackId)
        } else {
            musicDao.insertFavourite(
                FavouriteTrackEntity(
                    trackId = trackId,
                    addedAtMs = System.currentTimeMillis()
                )
            )
        }
    }

    override suspend fun recordRecentPlay(trackId: Long) = withContext(Dispatchers.IO) {
        val existing = musicDao.getRecentPlay(trackId)
        val nextCount = (existing?.playCount ?: 0) + 1
        musicDao.upsertRecentPlay(
            RecentPlayEntity(
                trackId = trackId,
                lastPlayedAtMs = System.currentTimeMillis(),
                playCount = nextCount
            )
        )
    }

    override suspend fun createPlaylist(name: String, description: String): Long =
        withContext(Dispatchers.IO) {
            musicDao.insertPlaylist(
                PlaylistEntity(
                    name = name.trim().ifEmpty { "My Playlist" },
                    description = description.trim(),
                    createdAtMs = System.currentTimeMillis()
                )
            )
        }

    override suspend fun renamePlaylist(playlistId: Long, newName: String, newDescription: String) =
        withContext(Dispatchers.IO) {
            musicDao.updatePlaylistMetadata(
                playlistId = playlistId,
                name = newName.trim().ifEmpty { "Untitled Playlist" },
                description = newDescription.trim()
            )
        }

    override suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        musicDao.deletePlaylistComplete(playlistId)
    }

    override suspend fun addTrackToPlaylist(playlistId: Long, trackId: Long) =
        withContext(Dispatchers.IO) {
            val nextOrder = musicDao.getNextPlaylistOrder(playlistId)
            musicDao.insertPlaylistTrackCrossRef(
                PlaylistTrackCrossRef(
                    playlistId = playlistId,
                    trackId = trackId,
                    positionOrder = nextOrder,
                    addedAtMs = System.currentTimeMillis()
                )
            )
        }

    override suspend fun removeTrackFromPlaylist(playlistId: Long, trackId: Long) =
        withContext(Dispatchers.IO) {
            musicDao.removeTrackFromPlaylist(playlistId, trackId)
        }

    override suspend fun loadLyricsForTrack(track: Track): List<LrcLine> =
        withContext(Dispatchers.IO) {
            // 1. Check user-imported custom LRC stored in Room
            musicDao.getCustomLrc(track.id)?.lrcContent?.let { raw ->
                val parsed = LrcParser.parse(raw)
                if (parsed.isNotEmpty()) return@withContext parsed
            }

            // 2. Check explicit lrcFilePath or sidecar .lrc next to audio file
            val sidecarFile = track.lrcFilePath?.let { File(it) }?.takeIf { it.exists() }
                ?: LrcParser.findSidecarLrcFile(track.filePath)
            if (sidecarFile != null && sidecarFile.canRead()) {
                val parsed = LrcParser.parse(sidecarFile.readText())
                if (parsed.isNotEmpty()) return@withContext parsed
            }

            // 3. Fallback if playing the bundled studio demo track
            if (track.id == 999_001L) {
                return@withContext try {
                    val assetLrc = context.assets.open("demo_emerald_horizons.lrc")
                        .bufferedReader()
                        .use { it.readText() }
                    LrcParser.parse(assetLrc)
                } catch (_: Exception) {
                    emptyList()
                }
            }

            emptyList()
        }

    override suspend fun saveCustomLyricsForTrack(
        trackId: Long,
        rawLrcContent: String
    ): List<LrcLine> = withContext(Dispatchers.IO) {
        musicDao.upsertCustomLrc(
            CustomLrcEntity(
                trackId = trackId,
                lrcContent = rawLrcContent,
                updatedAtMs = System.currentTimeMillis()
            )
        )
        LrcParser.parse(rawLrcContent)
    }

    override suspend fun setAmoledTheme(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AMOLED_THEME, enabled).apply()
        _isAmoledThemeFlow.value = enabled
    }

    companion object {
        private const val KEY_AMOLED_THEME = "amoled_theme_enabled"
    }
}
