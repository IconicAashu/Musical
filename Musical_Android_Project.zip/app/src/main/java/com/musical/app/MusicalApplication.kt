package com.musical.app

import android.app.Application
import com.musical.app.data.local.db.MusicalDatabase
import com.musical.app.data.local.scanner.LocalAudioScanner
import com.musical.app.data.repository.MusicRepositoryImpl
import com.musical.app.domain.repository.MusicRepository
import com.musical.app.playback.AudioEqualizerController
import com.musical.app.playback.PlaybackController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MusicalApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val database: MusicalDatabase by lazy {
        MusicalDatabase.getInstance(this)
    }

    val localAudioScanner: LocalAudioScanner by lazy {
        LocalAudioScanner(this)
    }

    val musicRepository: MusicRepository by lazy {
        MusicRepositoryImpl(
            context = this,
            musicDao = database.musicDao(),
            localAudioScanner = localAudioScanner
        )
    }

    val equalizerController: AudioEqualizerController by lazy {
        AudioEqualizerController()
    }

    val playbackController: PlaybackController by lazy {
        PlaybackController(
            context = this,
            scope = applicationScope,
            equalizerController = equalizerController,
            onTrackPlayed = { trackId ->
                applicationScope.launch {
                    musicRepository.recordRecentPlay(trackId)
                }
            }
        )
    }
}
