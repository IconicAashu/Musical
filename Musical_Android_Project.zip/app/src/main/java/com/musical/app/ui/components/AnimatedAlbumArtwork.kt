package com.musical.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.musical.app.ui.theme.AmoledBlack
import com.musical.app.ui.theme.EmeraldBright
import com.musical.app.ui.theme.EmeraldDeep
import com.musical.app.ui.theme.EmeraldPrimary
import kotlin.math.abs

@Composable
fun AnimatedAlbumArtwork(
    albumArtUri: String?,
    titleSeed: String,
    isPlaying: Boolean,
    size: Dp = 280.dp,
    isCircularVinyl: Boolean = true,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "vinyl_spin")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation_angle"
    )
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1_800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_pulse"
    )
    val scale by animateFloatAsState(
        targetValue = if (isPlaying) 1.0f else 0.92f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "artwork_scale"
    )

    val seedHash = abs(titleSeed.hashCode())
    val accentSecondary = Color(
        red = ((seedHash shr 16) and 0x7F) + 40,
        green = ((seedHash shr 8) and 0x7F) + 110,
        blue = (seedHash and 0x7F) + 80
    )

    val shape = if (isCircularVinyl) CircleShape else RoundedCornerShape(20.dp)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .scale(scale)
    ) {
        if (isPlaying) {
            Box(
                modifier = Modifier
                    .fillMaxSize(0.95f)
                    .scale(glowPulse)
                    .clip(shape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                EmeraldPrimary.copy(alpha = 0.38f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize(0.9f)
                .shadow(elevation = 24.dp, shape = shape, spotColor = EmeraldBright)
                .clip(shape)
                .rotate(if (isCircularVinyl && isPlaying) rotation else 0f)
                .background(
                    Brush.linearGradient(
                        colors = listOf(EmeraldDeep, accentSecondary, AmoledBlack)
                    )
                )
                .border(width = 2.dp, color = EmeraldPrimary.copy(alpha = 0.45f), shape = shape)
        ) {
            // Subtle vinyl grooves
            if (isCircularVinyl) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radii = listOf(0.88f, 0.76f, 0.64f, 0.52f, 0.40f)
                    for (r in radii) {
                        drawCircle(
                            color = Color.White.copy(alpha = 0.06f),
                            radius = (this.size.minDimension / 2f) * r,
                            style = Stroke(width = 1.5f)
                        )
                    }
                    drawCircle(
                        color = EmeraldPrimary.copy(alpha = 0.15f),
                        radius = this.size.minDimension * 0.22f
                    )
                }
            }

            if (!albumArtUri.isNullOrBlank()) {
                AsyncImage(
                    model = albumArtUri,
                    contentDescription = titleSeed,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = EmeraldBright,
                    modifier = Modifier.size(size * 0.34f)
                )
            }

            if (isCircularVinyl) {
                // Vinyl center spindle hole
                Box(
                    modifier = Modifier
                        .size(size * 0.12f)
                        .clip(CircleShape)
                        .background(AmoledBlack)
                        .border(2.dp, EmeraldPrimary, CircleShape)
                )
            }
        }
    }
}

@Composable
fun CompactTrackThumbnail(
    albumArtUri: String?,
    titleSeed: String,
    size: Dp = 50.dp,
    modifier: Modifier = Modifier
) {
    val seedHash = abs(titleSeed.hashCode())
    val gradientColor = Color(
        red = ((seedHash shr 12) and 0x5F) + 25,
        green = ((seedHash shr 6) and 0x7F) + 95,
        blue = (seedHash and 0x5F) + 50
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(EmeraldDeep, gradientColor),
                    start = Offset.Zero,
                    end = Offset(120f, 120f)
                )
            )
    ) {
        if (!albumArtUri.isNullOrBlank()) {
            AsyncImage(
                model = albumArtUri,
                contentDescription = titleSeed,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.MusicNote,
                contentDescription = null,
                tint = EmeraldBright,
                modifier = Modifier.size(size * 0.5f)
            )
        }
    }
}
