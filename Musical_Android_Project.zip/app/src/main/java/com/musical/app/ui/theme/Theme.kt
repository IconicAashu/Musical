package com.musical.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val AmoledColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = AmoledBlack,
    primaryContainer = EmeraldDeep,
    onPrimaryContainer = EmeraldBright,
    secondary = EmeraldBright,
    onSecondary = AmoledBlack,
    background = AmoledBlack,
    onBackground = TextPrimary,
    surface = AmoledSurface,
    onSurface = TextPrimary,
    surfaceVariant = AmoledCard,
    onSurfaceVariant = TextSecondary,
    outline = DividerSubtle
)

private val SpotifyDarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = AmoledBlack,
    primaryContainer = EmeraldDeep,
    onPrimaryContainer = EmeraldBright,
    secondary = EmeraldBright,
    onSecondary = AmoledBlack,
    background = SpotifyDarkBackground,
    onBackground = TextPrimary,
    surface = SpotifyDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = SpotifyDarkCard,
    onSurfaceVariant = TextSecondary,
    outline = DividerSubtle
)

@Composable
fun MusicalTheme(
    isAmoledMode: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isAmoledMode) AmoledColorScheme else SpotifyDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val barColor = colorScheme.background.toArgb()
            window.statusBarColor = barColor
            window.navigationBarColor = barColor
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = MusicalTypography,
        content = content
    )
}
