package com.musical.app.playback

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SleepTimerManager(
    private val scope: CoroutineScope,
    private val onTimerExpired: () -> Unit
) {
    private var timerJob: Job? = null

    private val _remainingMs = MutableStateFlow<Long?>(null)
    val remainingMs: StateFlow<Long?> = _remainingMs.asStateFlow()

    private val _stopAtEndOfTrack = MutableStateFlow(false)
    val stopAtEndOfTrack: StateFlow<Boolean> = _stopAtEndOfTrack.asStateFlow()

    fun startTimer(minutes: Int) {
        cancelTimer()
        if (minutes <= 0) return
        val totalMs = minutes * 60_000L
        _remainingMs.value = totalMs
        _stopAtEndOfTrack.value = false

        timerJob = scope.launch {
            var left = totalMs
            while (left > 0L) {
                delay(1_000L)
                left = (left - 1_000L).coerceAtLeast(0L)
                _remainingMs.value = left
            }
            _remainingMs.value = null
            onTimerExpired()
        }
    }

    fun setStopAtEndOfCurrentTrack(enabled: Boolean) {
        if (enabled) {
            timerJob?.cancel()
            timerJob = null
            _remainingMs.value = null
        }
        _stopAtEndOfTrack.value = enabled
    }

    fun onTrackTransitioned(): Boolean {
        return if (_stopAtEndOfTrack.value) {
            _stopAtEndOfTrack.value = false
            onTimerExpired()
            true
        } else {
            false
        }
    }

    fun cancelTimer() {
        timerJob?.cancel()
        timerJob = null
        _remainingMs.value = null
        _stopAtEndOfTrack.value = false
    }
}
