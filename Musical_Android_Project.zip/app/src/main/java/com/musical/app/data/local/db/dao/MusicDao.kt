package com.musical.app.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.musical.app.data.local.db.entity.CachedTrackEntity
import com.musical.app.data.local.db.entity.CustomLrcEntity
import com.musical.app.data.local.db.entity.FavouriteTrackEntity
import com.musical.app.data.local.db.entity.PlaylistEntity
import com.musical.app.data.local.db.entity.PlaylistTrackCrossRef
import com.musical.app.data.local.db.entity.RecentPlayEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MusicDao {
    // Cached tracks
    @Query("SELECT * FROM cached_tracks ORDER BY title COLLATE NOCASE ASC")
    fun observeCachedTracks(): Flow<List<CachedTrackEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCachedTracks(tracks: List<CachedTrackEntity>)

    // Favourites
    @Query("SELECT * FROM favourite_tracks ORDER BY addedAtMs DESC")
    fun observeFavourites(): Flow<List<FavouriteTrackEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favourite_tracks WHERE trackId = :trackId)")
    suspend fun isFavourite(trackId: Long): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavourite(entity: FavouriteTrackEntity)

    @Query("DELETE FROM favourite_tracks WHERE trackId = :trackId")
    suspend fun deleteFavourite(trackId: Long)

    // Recently Played
    @Query("SELECT * FROM recent_plays ORDER BY lastPlayedAtMs DESC LIMIT 50")
    fun observeRecentPlays(): Flow<List<RecentPlayEntity>>

    @Query("SELECT * FROM recent_plays WHERE trackId = :trackId LIMIT 1")
    suspend fun getRecentPlay(trackId: Long): RecentPlayEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecentPlay(entity: RecentPlayEntity)

    // Playlists
    @Query("SELECT * FROM playlists ORDER BY createdAtMs DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlist_tracks ORDER BY playlistId ASC, positionOrder ASC")
    fun observeAllPlaylistTrackRefs(): Flow<List<PlaylistTrackCrossRef>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name, description = :description WHERE id = :playlistId")
    suspend fun updatePlaylistMetadata(playlistId: Long, name: String, description: String)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylistById(playlistId: Long)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun deleteAllTracksFromPlaylist(playlistId: Long)

    @Transaction
    suspend fun deletePlaylistComplete(playlistId: Long) {
        deleteAllTracksFromPlaylist(playlistId)
        deletePlaylistById(playlistId)
    }

    @Query("SELECT COALESCE(MAX(positionOrder), -1) + 1 FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun getNextPlaylistOrder(playlistId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistTrackCrossRef(ref: PlaylistTrackCrossRef)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId")
    suspend fun removeTrackFromPlaylist(playlistId: Long, trackId: Long)

    // Custom Lyrics
    @Query("SELECT * FROM custom_lyrics WHERE trackId = :trackId LIMIT 1")
    suspend fun getCustomLrc(trackId: Long): CustomLrcEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCustomLrc(entity: CustomLrcEntity)
}
