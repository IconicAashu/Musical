package com.musical.app.domain.model

data class Artist(
    val id: Long,
    val name: String,
    val tracks: List<Track>,
    val albums: List<Album>
) {
    val trackCount: Int get() = tracks.size
    val albumCount: Int get() = albums.size
    val artworkUri: String? get() = tracks.firstOrNull { !it.albumArtUri.isNullOrBlank() }?.albumArtUri
}
