package com.musical.app.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favourite_tracks")
data class FavouriteTrackEntity(
    @PrimaryKey val trackId: Long,
    val addedAtMs: Long
)
