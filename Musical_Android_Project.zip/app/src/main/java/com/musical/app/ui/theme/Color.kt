package com.musical.app.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF1DB954)
val EmeraldBright = Color(0xFF1ED760)
val EmeraldDeep = Color(0xFF0E4D23)
val EmeraldGlow = Color(0x331DB954)

val AmoledBlack = Color(0xFF000000)
val AmoledSurface = Color(0xFF0A0A0A)
val AmoledCard = Color(0xFF111111)

val SpotifyDarkBackground = Color(0xFF121212)
val SpotifyDarkSurface = Color(0xFF181818)
val SpotifyDarkCard = Color(0xFF242424)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB3B3B3)
val TextMuted = Color(0xFF727272)
val DividerSubtle = Color(0xFF262626)
val CrimsonAccent = Color(0xFFE91E63)
