package com.musical.app.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recent_plays")
data class RecentPlayEntity(
    @PrimaryKey val trackId: Long,
    val lastPlayedAtMs: Long,
    val playCount: Int = 1
)
