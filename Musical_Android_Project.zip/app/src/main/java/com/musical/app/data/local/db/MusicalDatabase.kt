package com.musical.app.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.musical.app.data.local.db.dao.MusicDao
import com.musical.app.data.local.db.entity.CachedTrackEntity
import com.musical.app.data.local.db.entity.CustomLrcEntity
import com.musical.app.data.local.db.entity.FavouriteTrackEntity
import com.musical.app.data.local.db.entity.PlaylistEntity
import com.musical.app.data.local.db.entity.PlaylistTrackCrossRef
import com.musical.app.data.local.db.entity.RecentPlayEntity

@Database(
    entities = [
        CachedTrackEntity::class,
        FavouriteTrackEntity::class,
        RecentPlayEntity::class,
        PlaylistEntity::class,
        PlaylistTrackCrossRef::class,
        CustomLrcEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MusicalDatabase : RoomDatabase() {
    abstract fun musicDao(): MusicDao

    companion object {
        @Volatile
        private var INSTANCE: MusicalDatabase? = null

        fun getInstance(context: Context): MusicalDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MusicalDatabase::class.java,
                    "musical_app.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
