package com.musical.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.musical.app.domain.model.LrcLine
import com.musical.app.domain.model.Track
import com.musical.app.ui.theme.AmoledBlack
import com.musical.app.ui.theme.EmeraldDeep
import com.musical.app.ui.theme.EmeraldPrimary
import com.musical.app.ui.theme.TextMuted
import com.musical.app.ui.theme.TextPrimary
import com.musical.app.ui.theme.TextSecondary

@Composable
fun LyricsScreen(
    currentTrack: Track?,
    lyrics: List<LrcLine>,
    activeLineIndex: Int,
    onBack: () -> Unit,
    onSeekToLine: (Long) -> Unit,
    onSaveCustomLrc: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    var showEditLrcDialog by remember { mutableStateOf(false) }

    LaunchedEffect(activeLineIndex) {
        if (activeLineIndex >= 0 && activeLineIndex < lyrics.size) {
            listState.animateScrollToItem(
                index = (activeLineIndex - 2).coerceAtLeast(0)
            )
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        EmeraldDeep.copy(alpha = 0.7f),
                        MaterialTheme.colorScheme.background,
                        AmoledBlack
                    )
                )
            )
            .padding(top = 16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Column {
                    Text(
                        text = currentTrack?.title ?: "Synchronized Lyrics",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = "${currentTrack?.artist.orEmpty()} • Tap any line to seek",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary
                    )
                }
            }

            IconButton(onClick = { showEditLrcDialog = true }) {
                Icon(
                    imageVector = Icons.Rounded.EditNote,
                    contentDescription = "Paste or Edit LRC Lyrics",
                    tint = EmeraldPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (lyrics.isEmpty()) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp)
            ) {
                Text(
                    text = "No .lrc file found for this track",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Place a matching .lrc file alongside the audio file or paste timestamped LRC lyrics directly.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { showEditLrcDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = AmoledBlack
                    )
                ) {
                    Text("Add Custom .LRC Lyrics", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 48.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(lyrics, key = { idx, line -> "${idx}_${line.timestampMs}" }) { index, line ->
                    val isActive = index == activeLineIndex
                    val isPast = index < activeLineIndex

                    val lineColor by animateColorAsState(
                        targetValue = when {
                            isActive -> EmeraldPrimary
                            isPast -> TextSecondary.copy(alpha = 0.65f)
                            else -> TextMuted
                        },
                        label = "lyric_color"
                    )
                    val lineScale by animateFloatAsState(
                        targetValue = if (isActive) 1.04f else 1.0f,
                        label = "lyric_scale"
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .scale(lineScale)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isActive) EmeraldPrimary.copy(alpha = 0.12f)
                                else androidx.compose.ui.graphics.Color.Transparent
                            )
                            .clickable { onSeekToLine(line.timestampMs) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = line.formattedTime,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isActive) EmeraldPrimary else TextMuted
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = line.text,
                            style = if (isActive) {
                                MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold)
                            } else {
                                MaterialTheme.typography.titleMedium
                            },
                            color = lineColor
                        )
                    }
                }
            }
        }
    }

    if (showEditLrcDialog) {
        val initialText = remember(lyrics) {
            if (lyrics.isNotEmpty()) {
                lyrics.joinToString("
") { "[${it.formattedTime}.00]${it.text}" }
            } else {
                "[00:00.00]First line of synchronized lyrics
[00:04.50]Second line of synchronized lyrics
[00:09.00]Third line of synchronized lyrics"
            }
        }
        var lrcInput by remember { mutableStateOf(initialText) }

        AlertDialog(
            onDismissRequest = { showEditLrcDialog = false },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            title = { Text("Synchronized LRC Editor", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = lrcInput,
                    onValueChange = { lrcInput = it },
                    label = { Text("[mm:ss.xx] Lyric lines") },
                    minLines = 7,
                    maxLines = 12,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveCustomLrc(lrcInput)
                        showEditLrcDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = AmoledBlack
                    )
                ) {
                    Text("Save Lyrics")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditLrcDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
