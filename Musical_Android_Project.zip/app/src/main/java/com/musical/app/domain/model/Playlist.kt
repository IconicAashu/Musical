package com.musical.app.domain.model

data class Playlist(
    val id: Long,
    val name: String,
    val description: String,
    val createdAtMs: Long,
    val tracks: List<Track>
) {
    val trackCount: Int get() = tracks.size
    val coverArtUri: String? get() = tracks.firstOrNull { !it.albumArtUri.isNullOrBlank() }?.albumArtUri
    val totalDurationMs: Long get() = tracks.sumOf { it.durationMs }
}
