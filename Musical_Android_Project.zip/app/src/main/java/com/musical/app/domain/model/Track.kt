package com.musical.app.domain.model

data class Track(
    val id: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val artistId: Long,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val albumArtUri: String?,
    val filePath: String,
    val dateAddedSec: Long,
    val trackNumber: Int = 0,
    val year: Int = 0,
    val isFavourite: Boolean = false,
    val lrcFilePath: String? = null
) {
    val formattedDuration: String
        get() {
            val totalSeconds = (durationMs / 1000L).coerceAtLeast(0L)
            val minutes = totalSeconds / 60L
            val seconds = totalSeconds % 60L
            return "%d:%02d".format(minutes, seconds)
        }
}
