package com.musical.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.musical.app.domain.model.Album
import com.musical.app.domain.model.Artist
import com.musical.app.domain.model.Track
import com.musical.app.ui.components.CompactTrackThumbnail
import com.musical.app.ui.components.TrackRowItem
import com.musical.app.ui.theme.AmoledBlack
import com.musical.app.ui.theme.EmeraldPrimary
import com.musical.app.ui.theme.TextPrimary
import com.musical.app.ui.theme.TextSecondary
import com.musical.app.ui.viewmodel.MusicalUiState

@Composable
fun ArtistsAlbumsScreen(
    uiState: MusicalUiState,
    onPlayTrack: (Track, List<Track>) -> Unit,
    onPlayCollection: (List<Track>, Boolean) -> Unit,
    onToggleFavourite: (Long) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onAddToPlaylist: (Long, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAlbumsTab by remember { mutableStateOf(true) }
    var selectedAlbum by remember { mutableStateOf<Album?>(null) }
    var selectedArtist by remember { mutableStateOf<Artist?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(top = 16.dp)
    ) {
        val activeAlbum = selectedAlbum
        val activeArtist = selectedArtist

        if (activeAlbum != null) {
            // Album Detail View
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedAlbum = null }) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    CompactTrackThumbnail(
                        albumArtUri = activeAlbum.albumArtUri,
                        titleSeed = activeAlbum.title,
                        size = 52.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(activeAlbum.title, style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                        Text(
                            "${activeAlbum.artist} • ${activeAlbum.trackCount} songs",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
                Button(
                    onClick = { onPlayCollection(activeAlbum.tracks, false) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = AmoledBlack
                    )
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Text("Play")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
                items(activeAlbum.tracks, key = { "album_detail_${it.id}" }) { track ->
                    val isCurrent = uiState.playbackState.currentTrack?.id == track.id
                    TrackRowItem(
                        track = track,
                        isCurrentTrack = isCurrent,
                        isPlaying = isCurrent && uiState.playbackState.isPlaying,
                        playlists = uiState.playlists,
                        onTrackClick = { onPlayTrack(track, activeAlbum.tracks) },
                        onToggleFavourite = { onToggleFavourite(track.id) },
                        onPlayNext = { onPlayNext(track) },
                        onAddToQueue = { onAddToQueue(track) },
                        onAddToPlaylist = { plId -> onAddToPlaylist(plId, track.id) },
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }
        } else if (activeArtist != null) {
            // Artist Detail View
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedArtist = null }) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    CompactTrackThumbnail(
                        albumArtUri = activeArtist.artworkUri,
                        titleSeed = activeArtist.name,
                        size = 52.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(activeArtist.name, style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                        Text(
                            "${activeArtist.albumCount} albums • ${activeArtist.trackCount} tracks",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
                Button(
                    onClick = { onPlayCollection(activeArtist.tracks, true) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = AmoledBlack
                    )
                ) {
                    Icon(Icons.Rounded.Shuffle, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Shuffle")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
                items(activeArtist.tracks, key = { "artist_detail_${it.id}" }) { track ->
                    val isCurrent = uiState.playbackState.currentTrack?.id == track.id
                    TrackRowItem(
                        track = track,
                        isCurrentTrack = isCurrent,
                        isPlaying = isCurrent && uiState.playbackState.isPlaying,
                        playlists = uiState.playlists,
                        onTrackClick = { onPlayTrack(track, activeArtist.tracks) },
                        onToggleFavourite = { onToggleFavourite(track.id) },
                        onPlayNext = { onPlayNext(track) },
                        onAddToQueue = { onAddToQueue(track) },
                        onAddToPlaylist = { plId -> onAddToPlaylist(plId, track.id) },
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }
        } else {
            // Top Switcher between Albums and Artists
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = if (showAlbumsTab) "Albums" else "Artists",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = showAlbumsTab,
                        onClick = { showAlbumsTab = true },
                        label = {
                            Text(
                                "Albums (${uiState.albums.size})",
                                fontWeight = if (showAlbumsTab) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = AmoledBlack
                        )
                    )
                    FilterChip(
                        selected = !showAlbumsTab,
                        onClick = { showAlbumsTab = false },
                        label = {
                            Text(
                                "Artists (${uiState.artists.size})",
                                fontWeight = if (!showAlbumsTab) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = AmoledBlack
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, bottom = 140.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (showAlbumsTab) {
                    items(uiState.albums, key = { "album_${it.id}_${it.title}" }) { album ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedAlbum = album }
                                .padding(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                CompactTrackThumbnail(
                                    albumArtUri = album.albumArtUri,
                                    titleSeed = album.title,
                                    size = 60.dp
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = album.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "${album.artist} • ${album.trackCount} tracks",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                            }
                            IconButton(onClick = { onPlayCollection(album.tracks, false) }) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = "Play Album",
                                    tint = EmeraldPrimary
                                )
                            }
                        }
                    }
                } else {
                    items(uiState.artists, key = { "artist_${it.name}" }) { artist ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedArtist = artist }
                                .padding(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                CompactTrackThumbnail(
                                    albumArtUri = artist.artworkUri,
                                    titleSeed = artist.name,
                                    size = 60.dp
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = artist.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "${artist.albumCount} albums • ${artist.trackCount} songs",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                            }
                            IconButton(onClick = { onPlayCollection(artist.tracks, true) }) {
                                Icon(
                                    imageVector = Icons.Rounded.Shuffle,
                                    contentDescription = "Shuffle Artist",
                                    tint = EmeraldPrimary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
