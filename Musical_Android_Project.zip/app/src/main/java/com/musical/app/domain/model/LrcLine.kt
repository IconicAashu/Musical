package com.musical.app.domain.model

data class LrcLine(
    val timestampMs: Long,
    val text: String
) {
    val formattedTime: String
        get() {
            val totalSeconds = (timestampMs / 1000L).coerceAtLeast(0L)
            val minutes = totalSeconds / 60L
            val seconds = totalSeconds % 60L
            return "%02d:%02d".format(minutes, seconds)
        }
}
