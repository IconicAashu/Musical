package com.musical.app.playback

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import com.musical.app.domain.model.EqualizerBand
import com.musical.app.domain.model.EqualizerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class AudioEqualizerController {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var boundSessionId: Int = 0

    private val _state = MutableStateFlow(EqualizerState())
    val state: StateFlow<EqualizerState> = _state.asStateFlow()

    // Custom engineered 5-band curves in millibels (-1500..+1500)
    private val customPresetCurves: Map<String, List<Int>> = linkedMapOf(
        "Flat" to listOf(0, 0, 0, 0, 0),
        "Spotify Emerald Bass" to listOf(650, 450, 0, 200, 350),
        "Acoustic Warmth" to listOf(300, 250, 100, 300, 200),
        "Electronic Pulse" to listOf(700, 300, -150, 350, 600),
        "Vocal Clarity" to listOf(-200, 150, 550, 450, 150),
        "Rock Arena" to listOf(550, 300, -100, 400, 550),
        "Late Night Lounge" to listOf(400, 200, -200, -150, 250)
    )

    fun bindToAudioSession(audioSessionId: Int) {
        if (audioSessionId <= 0 || audioSessionId == boundSessionId) return
        releaseEffects()
        boundSessionId = audioSessionId

        try {
            val eq = Equalizer(0, audioSessionId).apply {
                enabled = _state.value.enabled
            }
            equalizer = eq

            val numBands = eq.numberOfBands.toInt()
            val levelRange = eq.bandLevelRange
            val minMb = levelRange.getOrNull(0)?.toInt() ?: -1500
            val maxMb = levelRange.getOrNull(1)?.toInt() ?: 1500

            val hardwareBands = (0 until numBands).map { idx ->
                val bandShort = idx.toShort()
                val centerFreqHz = (eq.getCenterFreq(bandShort) / 1000).coerceAtLeast(20)
                val currentLevel = eq.getBandLevel(bandShort).toInt()
                EqualizerBand(
                    index = idx,
                    centerFreqHz = centerFreqHz,
                    minLevelMb = minMb,
                    maxLevelMb = maxMb,
                    currentLevelMb = currentLevel
                )
            }

            val bb = runCatching {
                BassBoost(0, audioSessionId).apply {
                    enabled = _state.value.enabled
                    if (strengthSupported) {
                        setStrength(_state.value.bassBoostStrength.toShort())
                    }
                }
            }.getOrNull()
            bassBoost = bb

            val virt = runCatching {
                Virtualizer(0, audioSessionId).apply {
                    enabled = _state.value.enabled
                    if (strengthSupported) {
                        setStrength(_state.value.virtualizerStrength.toShort())
                    }
                }
            }.getOrNull()
            virtualizer = virt

            _state.update { current ->
                current.copy(
                    audioSessionId = audioSessionId,
                    bands = if (hardwareBands.isNotEmpty()) hardwareBands else EqualizerState.defaultBands(),
                    presetNames = customPresetCurves.keys.toList()
                )
            }
        } catch (_: Exception) {
            // Hardware AudioEffect unavailable on this device/session; retain software UI state
            _state.update { it.copy(audioSessionId = audioSessionId) }
        }
    }

    fun setEnabled(enabled: Boolean) {
        runCatching { equalizer?.enabled = enabled }
        runCatching { bassBoost?.enabled = enabled }
        runCatching { virtualizer?.enabled = enabled }
        _state.update { it.copy(enabled = enabled) }
    }

    fun setBandLevel(bandIndex: Int, levelMb: Int) {
        val currentBands = _state.value.bands
        val targetBand = currentBands.getOrNull(bandIndex) ?: return
        val clamped = levelMb.coerceIn(targetBand.minLevelMb, targetBand.maxLevelMb)

        runCatching {
            equalizer?.setBandLevel(bandIndex.toShort(), clamped.toShort())
        }

        val updatedBands = currentBands.map { band ->
            if (band.index == bandIndex) band.copy(currentLevelMb = clamped) else band
        }
        _state.update { it.copy(bands = updatedBands, selectedPresetIndex = -1) }
    }

    fun selectPreset(presetIndex: Int) {
        val names = _state.value.presetNames
        val presetName = names.getOrNull(presetIndex) ?: return
        val curve = customPresetCurves[presetName] ?: return

        val updatedBands = _state.value.bands.mapIndexed { idx, band ->
            val desiredMb = curve.getOrElse(idx) { 0 }.coerceIn(band.minLevelMb, band.maxLevelMb)
            runCatching {
                equalizer?.setBandLevel(idx.toShort(), desiredMb.toShort())
            }
            band.copy(currentLevelMb = desiredMb)
        }

        _state.update {
            it.copy(
                selectedPresetIndex = presetIndex,
                bands = updatedBands,
                enabled = true
            )
        }
        runCatching { equalizer?.enabled = true }
    }

    fun setBassBoostStrength(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        runCatching {
            bassBoost?.let { bb ->
                if (bb.strengthSupported) bb.setStrength(clamped.toShort())
            }
        }
        _state.update { it.copy(bassBoostStrength = clamped) }
    }

    fun setVirtualizerStrength(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        runCatching {
            virtualizer?.let { virt ->
                if (virt.strengthSupported) virt.setStrength(clamped.toShort())
            }
        }
        _state.update { it.copy(virtualizerStrength = clamped) }
    }

    fun releaseEffects() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
        boundSessionId = 0
    }
}
