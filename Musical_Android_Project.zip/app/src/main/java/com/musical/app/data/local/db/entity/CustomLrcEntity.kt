package com.musical.app.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "custom_lyrics")
data class CustomLrcEntity(
    @PrimaryKey val trackId: Long,
    val lrcContent: String,
    val updatedAtMs: Long
)
