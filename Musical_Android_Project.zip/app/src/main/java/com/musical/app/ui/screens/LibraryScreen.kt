package com.musical.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.musical.app.domain.model.Playlist
import com.musical.app.domain.model.Track
import com.musical.app.ui.components.CompactTrackThumbnail
import com.musical.app.ui.components.TrackRowItem
import com.musical.app.ui.theme.AmoledBlack
import com.musical.app.ui.theme.EmeraldPrimary
import com.musical.app.ui.theme.TextPrimary
import com.musical.app.ui.theme.TextSecondary
import com.musical.app.ui.viewmodel.LibrarySortOrder
import com.musical.app.ui.viewmodel.MusicalUiState

@Composable
fun LibraryScreen(
    uiState: MusicalUiState,
    initialTab: Int = 0,
    onSortOrderChange: (LibrarySortOrder) -> Unit,
    onCreatePlaylist: (String, String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onRemoveTrackFromPlaylist: (Long, Long) -> Unit,
    onPlayTrack: (Track, List<Track>) -> Unit,
    onToggleFavourite: (Long) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onAddToPlaylist: (Long, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var selectedPlaylistId by remember { mutableStateOf<Long?>(null) }

    val tabs = listOf("Playlists", "Liked Songs", "Recent", "All Songs")
    val activePlaylist: Playlist? = uiState.playlists.firstOrNull { it.id == selectedPlaylistId }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(top = 16.dp)
    ) {
        if (activePlaylist != null) {
            // Playlist Detail View
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedPlaylistId = null }) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Column {
                        Text(
                            text = activePlaylist.name,
                            style = MaterialTheme.typography.headlineSmall,
                            color = TextPrimary
                        )
                        Text(
                            text = "${activePlaylist.trackCount} songs • ${activePlaylist.description.ifEmpty { "Custom Playlist" }}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
                Row {
                    if (activePlaylist.tracks.isNotEmpty()) {
                        Button(
                            onClick = { onPlayTrack(activePlaylist.tracks.first(), activePlaylist.tracks) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldPrimary,
                                contentColor = AmoledBlack
                            )
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Play")
                        }
                    }
                    IconButton(
                        onClick = {
                            onDeletePlaylist(activePlaylist.id)
                            selectedPlaylistId = null
                        }
                    ) {
                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete Playlist", tint = TextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                contentPadding = PaddingValues(bottom = 140.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (activePlaylist.tracks.isEmpty()) {
                    item {
                        Text(
                            text = "This playlist is empty. Tap the 3-dot menu on any song to add it here.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else {
                    items(activePlaylist.tracks, key = { "pl_track_${it.id}" }) { track ->
                        val isCurrent = uiState.playbackState.currentTrack?.id == track.id
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TrackRowItem(
                                track = track,
                                isCurrentTrack = isCurrent,
                                isPlaying = isCurrent && uiState.playbackState.isPlaying,
                                playlists = uiState.playlists,
                                onTrackClick = { onPlayTrack(track, activePlaylist.tracks) },
                                onToggleFavourite = { onToggleFavourite(track.id) },
                                onPlayNext = { onPlayNext(track) },
                                onAddToQueue = { onAddToQueue(track) },
                                onAddToPlaylist = { plId -> onAddToPlaylist(plId, track.id) },
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { onRemoveTrackFromPlaylist(activePlaylist.id, track.id) }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = "Remove from playlist",
                                    tint = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Top Library Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = "Your Library",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )

                Button(
                    onClick = { showCreatePlaylistDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = AmoledBlack
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Playlist", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Library Section Filter Chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tabs.size) { index ->
                    val selected = selectedTab == index
                    FilterChip(
                        selected = selected,
                        onClick = { selectedTab = index },
                        label = {
                            Text(
                                text = tabs[index],
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = AmoledBlack,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            labelColor = TextPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                contentPadding = PaddingValues(bottom = 140.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                when (selectedTab) {
                    0 -> {
                        // Custom Playlists Tab
                        if (uiState.playlists.isEmpty()) {
                            item {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "No custom playlists yet",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Create a custom playlist to organize your favourite local tracks.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                            }
                        } else {
                            items(uiState.playlists, key = { "playlist_${it.id}" }) { playlist ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { selectedPlaylistId = playlist.id }
                                        .padding(12.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CompactTrackThumbnail(
                                            albumArtUri = playlist.coverArtUri,
                                            titleSeed = playlist.name,
                                            size = 54.dp
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = playlist.name,
                                                style = MaterialTheme.typography.titleMedium,
                                                color = TextPrimary
                                            )
                                            Text(
                                                text = "${playlist.trackCount} songs • ${playlist.description.ifEmpty { "Playlist" }}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = TextSecondary
                                            )
                                        }
                                    }
                                    IconButton(onClick = { onDeletePlaylist(playlist.id) }) {
                                        Icon(
                                            imageVector = Icons.Rounded.DeleteOutline,
                                            contentDescription = "Delete",
                                            tint = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // Favourites Tab
                        if (uiState.favouriteTracks.isEmpty()) {
                            item {
                                Text(
                                    text = "Tap the heart icon on any song to save it to Liked Songs.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        } else {
                            items(uiState.favouriteTracks, key = { "fav_${it.id}" }) { track ->
                                val isCurrent = uiState.playbackState.currentTrack?.id == track.id
                                TrackRowItem(
                                    track = track,
                                    isCurrentTrack = isCurrent,
                                    isPlaying = isCurrent && uiState.playbackState.isPlaying,
                                    playlists = uiState.playlists,
                                    onTrackClick = { onPlayTrack(track, uiState.favouriteTracks) },
                                    onToggleFavourite = { onToggleFavourite(track.id) },
                                    onPlayNext = { onPlayNext(track) },
                                    onAddToQueue = { onAddToQueue(track) },
                                    onAddToPlaylist = { plId -> onAddToPlaylist(plId, track.id) },
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                            }
                        }
                    }

                    2 -> {
                        // Recently Played Tab
                        if (uiState.recentlyPlayed.isEmpty()) {
                            item {
                                Text(
                                    text = "Tracks you play will automatically appear here.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        } else {
                            items(uiState.recentlyPlayed, key = { "recent_tab_${it.id}" }) { track ->
                                val isCurrent = uiState.playbackState.currentTrack?.id == track.id
                                TrackRowItem(
                                    track = track,
                                    isCurrentTrack = isCurrent,
                                    isPlaying = isCurrent && uiState.playbackState.isPlaying,
                                    playlists = uiState.playlists,
                                    onTrackClick = { onPlayTrack(track, uiState.recentlyPlayed) },
                                    onToggleFavourite = { onToggleFavourite(track.id) },
                                    onPlayNext = { onPlayNext(track) },
                                    onAddToQueue = { onAddToQueue(track) },
                                    onAddToPlaylist = { plId -> onAddToPlaylist(plId, track.id) },
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                            }
                        }
                    }

                    3 -> {
                        // All Songs with Sort Selector
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(LibrarySortOrder.entries) { order ->
                                    FilterChip(
                                        selected = uiState.sortOrder == order,
                                        onClick = { onSortOrderChange(order) },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.Sort, contentDescription = null)
                                        },
                                        label = { Text(order.label) }
                                    )
                                }
                            }
                        }
                        items(uiState.sortedTracks, key = { "lib_all_${it.id}" }) { track ->
                            val isCurrent = uiState.playbackState.currentTrack?.id == track.id
                            TrackRowItem(
                                track = track,
                                isCurrentTrack = isCurrent,
                                isPlaying = isCurrent && uiState.playbackState.isPlaying,
                                playlists = uiState.playlists,
                                onTrackClick = { onPlayTrack(track, uiState.sortedTracks) },
                                onToggleFavourite = { onToggleFavourite(track.id) },
                                onPlayNext = { onPlayNext(track) },
                                onAddToQueue = { onAddToQueue(track) },
                                onAddToPlaylist = { plId -> onAddToPlaylist(plId, track.id) },
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreatePlaylistDialog) {
        var nameInput by remember { mutableStateOf("") }
        var descInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreatePlaylistDialog = false },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            title = { Text("Create Custom Playlist", color = TextPrimary) },
            text = {
                Column {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Playlist Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("Description (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCreatePlaylist(nameInput, descInput)
                        showCreatePlaylistDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = AmoledBlack
                    )
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreatePlaylistDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
