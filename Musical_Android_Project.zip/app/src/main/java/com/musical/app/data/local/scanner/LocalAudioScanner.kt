package com.musical.app.data.local.scanner

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.musical.app.domain.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class LocalAudioScanner(private val context: Context) {

    suspend fun scanLocalAudioFiles(): List<Track> = withContext(Dispatchers.IO) {
        val discoveredTracks = mutableListOf<Track>()
        val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ARTIST_ID,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.IS_MUSIC
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 3000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        try {
            context.contentResolver.query(
                collection,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val artistIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST_ID)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val yearCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)

                val albumArtBaseUri = Uri.parse("content://media/external/audio/albumart")

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val rawTitle = cursor.getString(titleCol)?.trim().orEmpty()
                    val rawArtist = cursor.getString(artistCol)?.trim().orEmpty()
                    val artistId = cursor.getLong(artistIdCol)
                    val rawAlbum = cursor.getString(albumCol)?.trim().orEmpty()
                    val albumId = cursor.getLong(albumIdCol)
                    val durationMs = cursor.getLong(durationCol)
                    val filePath = cursor.getString(dataCol).orEmpty()
                    val dateAddedSec = cursor.getLong(dateAddedCol)
                    val rawTrackNum = cursor.getInt(trackCol)
                    val year = cursor.getInt(yearCol)

                    val contentUri = ContentUris.withAppendedId(collection, id).toString()
                    val albumArtUri = ContentUris.withAppendedId(albumArtBaseUri, albumId).toString()
                    val sidecarLrc = LrcParser.findSidecarLrcFile(filePath)?.absolutePath

                    val cleanArtist = if (rawArtist.isEmpty() || rawArtist == "<unknown>") {
                        "Unknown Artist"
                    } else rawArtist
                    val cleanAlbum = if (rawAlbum.isEmpty() || rawAlbum == "<unknown>") {
                        "Unknown Album"
                    } else rawAlbum
                    val cleanTitle = if (rawTitle.isEmpty()) {
                        File(filePath).nameWithoutExtension.ifEmpty { "Track #$id" }
                    } else rawTitle

                    discoveredTracks.add(
                        Track(
                            id = id,
                            uri = contentUri,
                            title = cleanTitle,
                            artist = cleanArtist,
                            artistId = artistId,
                            album = cleanAlbum,
                            albumId = albumId,
                            durationMs = durationMs,
                            albumArtUri = albumArtUri,
                            filePath = filePath,
                            dateAddedSec = dateAddedSec,
                            trackNumber = rawTrackNum % 1000,
                            year = year,
                            isFavourite = false,
                            lrcFilePath = sidecarLrc
                        )
                    )
                }
            }
        } catch (_: SecurityException) {
            // Permission not granted yet; fallback studio track will still be provided below
        } catch (_: Exception) {
            // Ignore provider errors and ensure bundled studio track is available
        }

        // Always ensure bundled studio master WAV + synchronized LRC is unpacked in app storage
        // so playback, equalizer, and LRC lyrics work out of the box even on empty emulators.
        val bundledTrack = ensureBundledStudioTrack()
        if (bundledTrack != null && discoveredTracks.none { it.id == bundledTrack.id }) {
            discoveredTracks.add(0, bundledTrack)
        }

        discoveredTracks
    }

    private fun ensureBundledStudioTrack(): Track? {
        return try {
            val studioDir = File(context.filesDir, "studio_tracks")
            if (!studioDir.exists()) studioDir.mkdirs()

            val wavFile = File(studioDir, "demo_emerald_horizons.wav")
            val lrcFile = File(studioDir, "demo_emerald_horizons.lrc")

            if (!wavFile.exists() || wavFile.length() == 0L) {
                context.assets.open("demo_emerald_horizons.wav").use { input ->
                    FileOutputStream(wavFile).use { output -> input.copyTo(output) }
                }
            }
            if (!lrcFile.exists() || lrcFile.length() == 0L) {
                context.assets.open("demo_emerald_horizons.lrc").use { input ->
                    FileOutputStream(lrcFile).use { output -> input.copyTo(output) }
                }
            }

            Track(
                id = 999_001L,
                uri = Uri.fromFile(wavFile).toString(),
                title = "Emerald Horizons (Studio Master)",
                artist = "Musical Synth Ensemble",
                artistId = 9001L,
                album = "AMOLED Sessions Vol. 1",
                albumId = 8001L,
                durationMs = 24_000L,
                albumArtUri = null,
                filePath = wavFile.absolutePath,
                dateAddedSec = System.currentTimeMillis() / 1000L,
                trackNumber = 1,
                year = 2026,
                isFavourite = false,
                lrcFilePath = lrcFile.absolutePath
            )
        } catch (_: Exception) {
            null
        }
    }
}
