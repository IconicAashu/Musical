package com.musical.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.musical.app.domain.model.Track
import com.musical.app.ui.components.CompactTrackThumbnail
import com.musical.app.ui.components.TrackRowItem
import com.musical.app.ui.theme.AmoledBlack
import com.musical.app.ui.theme.EmeraldDeep
import com.musical.app.ui.theme.EmeraldPrimary
import com.musical.app.ui.theme.TextPrimary
import com.musical.app.ui.theme.TextSecondary
import com.musical.app.ui.viewmodel.MusicalUiState
import java.util.Calendar

@Composable
fun HomeScreen(
    uiState: MusicalUiState,
    onPlayTrack: (Track, List<Track>) -> Unit,
    onShuffleAll: () -> Unit,
    onRescanMusic: () -> Unit,
    onToggleAmoled: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    onNavigateToFavourites: () -> Unit,
    onNavigateToRecent: () -> Unit,
    onNavigateToAlbums: () -> Unit,
    onToggleFavourite: (Long) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onAddToPlaylist: (Long, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val greeting = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Late night session"
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 140.dp),
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        EmeraldDeep.copy(alpha = 0.45f),
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.background
                    )
                )
            )
    ) {
        // Top Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 18.dp)
            ) {
                Column {
                    Text(
                        text = greeting,
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = if (uiState.isAmoledTheme) "AMOLED Pure Black • ${uiState.allTracks.size} tracks"
                        else "Spotify Dark • ${uiState.allTracks.size} tracks",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onOpenSleepTimer) {
                        Icon(
                            imageVector = Icons.Rounded.Bedtime,
                            contentDescription = "Sleep Timer",
                            tint = if (uiState.playbackState.sleepTimerRemainingMs != null || uiState.playbackState.stopAtEndOfTrack) {
                                EmeraldPrimary
                            } else TextPrimary
                        )
                    }
                    IconButton(onClick = onOpenEqualizer) {
                        Icon(
                            imageVector = Icons.Rounded.Equalizer,
                            contentDescription = "Equalizer",
                            tint = if (uiState.equalizerState.enabled) EmeraldPrimary else TextPrimary
                        )
                    }
                    IconButton(onClick = onToggleAmoled) {
                        Icon(
                            imageVector = Icons.Rounded.Contrast,
                            contentDescription = "Toggle AMOLED Black Theme",
                            tint = if (uiState.isAmoledTheme) EmeraldPrimary else TextSecondary
                        )
                    }
                    IconButton(onClick = onRescanMusic) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Rescan Local Audio",
                            tint = TextPrimary
                        )
                    }
                }
            }
        }

        // Spotify-Style 2x2 Quick Access Grid
        item {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    QuickAccessTile(
                        title = "Liked Songs",
                        subtitle = "${uiState.favouriteTracks.size} saved",
                        icon = Icons.Rounded.Favorite,
                        iconTint = EmeraldPrimary,
                        onClick = onNavigateToFavourites,
                        modifier = Modifier.weight(1f)
                    )
                    QuickAccessTile(
                        title = "Recently Played",
                        subtitle = "${uiState.recentlyPlayed.size} tracks",
                        icon = Icons.Rounded.History,
                        iconTint = Color(0xFF29B6F6),
                        onClick = onNavigateToRecent,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    QuickAccessTile(
                        title = "Albums & Artists",
                        subtitle = "${uiState.albums.size} albums",
                        icon = Icons.Rounded.Album,
                        iconTint = Color(0xFFAB47BC),
                        onClick = onNavigateToAlbums,
                        modifier = Modifier.weight(1f)
                    )
                    QuickAccessTile(
                        title = "Audio Equalizer",
                        subtitle = if (uiState.equalizerState.enabled) "Active DSP" else "5-Band + Bass",
                        icon = Icons.Rounded.Equalizer,
                        iconTint = Color(0xFFFFA726),
                        onClick = onOpenEqualizer,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Recently Played Horizontal Carousel
        if (uiState.recentlyPlayed.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Jump back in",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(uiState.recentlyPlayed.take(12), key = { "recent_${it.id}" }) { track ->
                        Column(
                            modifier = Modifier
                                .width(132.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onPlayTrack(track, uiState.recentlyPlayed) }
                                .padding(6.dp)
                        ) {
                            CompactTrackThumbnail(
                                albumArtUri = track.albumArtUri,
                                titleSeed = track.title,
                                size = 120.dp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = track.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = track.artist,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // All Local Tracks Section Header + Shuffle Button
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column {
                    Text(
                        text = "Local Music Library",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    Text(
                        text = "MediaStore + Built-in Studio Track",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }

                Button(
                    onClick = onShuffleAll,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = AmoledBlack
                    ),
                    shape = CircleShape,
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shuffle,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Shuffle Play",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        // All Tracks List
        items(uiState.sortedTracks, key = { "home_track_${it.id}" }) { track ->
            val isCurrent = uiState.playbackState.currentTrack?.id == track.id
            TrackRowItem(
                track = track,
                isCurrentTrack = isCurrent,
                isPlaying = isCurrent && uiState.playbackState.isPlaying,
                playlists = uiState.playlists,
                onTrackClick = { onPlayTrack(track, uiState.sortedTracks) },
                onToggleFavourite = { onToggleFavourite(track.id) },
                onPlayNext = { onPlayNext(track) },
                onAddToQueue = { onAddToQueue(track) },
                onAddToPlaylist = { playlistId -> onAddToPlaylist(playlistId, track.id) },
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        }
    }
}

@Composable
private fun QuickAccessTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .height(60.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(60.dp)
                .background(iconTint.copy(alpha = 0.18f))
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.padding(end = 8.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
