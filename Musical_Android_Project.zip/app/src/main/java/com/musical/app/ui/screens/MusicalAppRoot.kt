package com.musical.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.musical.app.ui.components.MiniPlayerBar
import com.musical.app.ui.components.SleepTimerDialog
import com.musical.app.ui.theme.EmeraldPrimary
import com.musical.app.ui.theme.MusicalTheme
import com.musical.app.ui.theme.TextPrimary
import com.musical.app.ui.theme.TextSecondary
import com.musical.app.ui.viewmodel.MusicalViewModel

private enum class BottomNavDestination(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Home),
    SEARCH("Search", Icons.Rounded.Search),
    ALBUMS("Artists & Albums", Icons.Rounded.Album),
    LIBRARY("Library", Icons.Rounded.LibraryMusic)
}

private enum class ModalOverlay {
    NONE,
    NOW_PLAYING,
    LYRICS,
    EQUALIZER,
    QUEUE
}

@Composable
fun MusicalAppRoot(viewModel: MusicalViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    var currentNav by remember { mutableStateOf(BottomNavDestination.HOME) }
    var libraryInitialTab by remember { mutableIntStateOf(0) }
    var activeOverlay by remember { mutableStateOf(ModalOverlay.NONE) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }

    MusicalTheme(isAmoledMode = uiState.isAmoledTheme) {
        Box(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    Column {
                        if (uiState.playbackState.currentTrack != null && activeOverlay == ModalOverlay.NONE) {
                            MiniPlayerBar(
                                playbackState = uiState.playbackState,
                                onExpandPlayer = { activeOverlay = ModalOverlay.NOW_PLAYING },
                                onTogglePlayPause = viewModel::togglePlayPause,
                                onSkipNext = viewModel::skipNext,
                                onToggleFavourite = viewModel::toggleFavourite
                            )
                        }

                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            BottomNavDestination.entries.forEach { destination ->
                                val selected = currentNav == destination
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        currentNav = destination
                                        activeOverlay = ModalOverlay.NONE
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = destination.icon,
                                            contentDescription = destination.label
                                        )
                                    },
                                    label = { Text(destination.label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EmeraldPrimary,
                                        selectedTextColor = EmeraldPrimary,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary,
                                        indicatorColor = EmeraldPrimary.copy(alpha = 0.16f)
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentNav) {
                        BottomNavDestination.HOME -> HomeScreen(
                            uiState = uiState,
                            onPlayTrack = viewModel::playTrack,
                            onShuffleAll = { viewModel.playCollection(uiState.allTracks, shuffle = true) },
                            onRescanMusic = viewModel::scanLocalMusic,
                            onToggleAmoled = viewModel::toggleAmoledTheme,
                            onOpenEqualizer = { activeOverlay = ModalOverlay.EQUALIZER },
                            onOpenSleepTimer = { showSleepTimerDialog = true },
                            onNavigateToFavourites = {
                                libraryInitialTab = 1
                                currentNav = BottomNavDestination.LIBRARY
                            },
                            onNavigateToRecent = {
                                libraryInitialTab = 2
                                currentNav = BottomNavDestination.LIBRARY
                            },
                            onNavigateToAlbums = {
                                currentNav = BottomNavDestination.ALBUMS
                            },
                            onToggleFavourite = viewModel::toggleFavourite,
                            onPlayNext = viewModel::playNextInQueue,
                            onAddToQueue = viewModel::addToQueue,
                            onAddToPlaylist = viewModel::addTrackToPlaylist
                        )

                        BottomNavDestination.SEARCH -> SearchScreen(
                            uiState = uiState,
                            onQueryChange = viewModel::updateSearchQuery,
                            onFilterChange = viewModel::updateSearchFilter,
                            onPlayTrack = viewModel::playTrack,
                            onToggleFavourite = viewModel::toggleFavourite,
                            onPlayNext = viewModel::playNextInQueue,
                            onAddToQueue = viewModel::addToQueue,
                            onAddToPlaylist = viewModel::addTrackToPlaylist
                        )

                        BottomNavDestination.ALBUMS -> ArtistsAlbumsScreen(
                            uiState = uiState,
                            onPlayTrack = viewModel::playTrack,
                            onPlayCollection = viewModel::playCollection,
                            onToggleFavourite = viewModel::toggleFavourite,
                            onPlayNext = viewModel::playNextInQueue,
                            onAddToQueue = viewModel::addToQueue,
                            onAddToPlaylist = viewModel::addTrackToPlaylist
                        )

                        BottomNavDestination.LIBRARY -> LibraryScreen(
                            uiState = uiState,
                            initialTab = libraryInitialTab,
                            onSortOrderChange = viewModel::updateSortOrder,
                            onCreatePlaylist = viewModel::createPlaylist,
                            onDeletePlaylist = viewModel::deletePlaylist,
                            onRemoveTrackFromPlaylist = viewModel::removeTrackFromPlaylist,
                            onPlayTrack = viewModel::playTrack,
                            onToggleFavourite = viewModel::toggleFavourite,
                            onPlayNext = viewModel::playNextInQueue,
                            onAddToQueue = viewModel::addToQueue,
                            onAddToPlaylist = viewModel::addTrackToPlaylist
                        )
                    }
                }
            }

            // Full-Screen Overlays (Now Playing, Lyrics, Equalizer, Queue)
            AnimatedVisibility(
                visible = activeOverlay != ModalOverlay.NONE,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                when (activeOverlay) {
                    ModalOverlay.NOW_PLAYING -> NowPlayingScreen(
                        playbackState = uiState.playbackState,
                        hasLyrics = uiState.currentLyrics.isNotEmpty(),
                        isEqualizerEnabled = uiState.equalizerState.enabled,
                        onCollapse = { activeOverlay = ModalOverlay.NONE },
                        onTogglePlayPause = viewModel::togglePlayPause,
                        onSeekTo = viewModel::seekTo,
                        onSkipNext = viewModel::skipNext,
                        onSkipPrevious = viewModel::skipPrevious,
                        onToggleShuffle = viewModel::toggleShuffle,
                        onCycleRepeat = viewModel::cycleRepeatMode,
                        onToggleFavourite = viewModel::toggleFavourite,
                        onOpenLyrics = { activeOverlay = ModalOverlay.LYRICS },
                        onOpenQueue = { activeOverlay = ModalOverlay.QUEUE },
                        onOpenEqualizer = { activeOverlay = ModalOverlay.EQUALIZER },
                        onOpenSleepTimer = { showSleepTimerDialog = true }
                    )

                    ModalOverlay.LYRICS -> LyricsScreen(
                        currentTrack = uiState.playbackState.currentTrack,
                        lyrics = uiState.currentLyrics,
                        activeLineIndex = uiState.activeLyricIndex,
                        onBack = { activeOverlay = ModalOverlay.NOW_PLAYING },
                        onSeekToLine = viewModel::seekTo,
                        onSaveCustomLrc = viewModel::saveCustomLrcLyrics
                    )

                    ModalOverlay.EQUALIZER -> EqualizerScreen(
                        equalizerState = uiState.equalizerState,
                        onBack = {
                            activeOverlay = if (uiState.playbackState.currentTrack != null) {
                                ModalOverlay.NOW_PLAYING
                            } else ModalOverlay.NONE
                        },
                        onToggleEnabled = viewModel::setEqualizerEnabled,
                        onSelectPreset = viewModel::selectEqualizerPreset,
                        onBandLevelChanged = viewModel::setEqualizerBandLevel,
                        onBassBoostChanged = viewModel::setBassBoostStrength,
                        onVirtualizerChanged = viewModel::setVirtualizerStrength
                    )

                    ModalOverlay.QUEUE -> QueueSheet(
                        playbackState = uiState.playbackState,
                        onBack = { activeOverlay = ModalOverlay.NOW_PLAYING },
                        onSelectQueueTrack = viewModel::playTrack,
                        onMoveQueueItem = viewModel::moveQueueItem,
                        onRemoveQueueItem = viewModel::removeFromQueue,
                        onClearQueue = viewModel::clearQueue
                    )

                    ModalOverlay.NONE -> Unit
                }
            }

            if (showSleepTimerDialog) {
                SleepTimerDialog(
                    remainingMs = uiState.playbackState.sleepTimerRemainingMs,
                    stopAtEndOfTrack = uiState.playbackState.stopAtEndOfTrack,
                    onStartMinutes = viewModel::startSleepTimer,
                    onToggleStopAtEndOfTrack = viewModel::setStopAtEndOfCurrentTrack,
                    onCancelTimer = viewModel::cancelSleepTimer,
                    onDismiss = { showSleepTimerDialog = false }
                )
            }
        }
    }
}
