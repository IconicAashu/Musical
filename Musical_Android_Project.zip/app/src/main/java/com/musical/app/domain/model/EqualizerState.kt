package com.musical.app.domain.model

data class EqualizerBand(
    val index: Int,
    val centerFreqHz: Int,
    val minLevelMb: Int,
    val maxLevelMb: Int,
    val currentLevelMb: Int
) {
    val formattedFrequency: String
        get() = if (centerFreqHz >= 1000) {
            val khz = centerFreqHz / 1000f
            if (centerFreqHz % 1000 == 0) "${centerFreqHz / 1000}kHz"
            else "%.1fkHz".format(khz)
        } else {
            "${centerFreqHz}Hz"
        }

    val currentDb: Float
        get() = currentLevelMb / 100f
}

data class EqualizerState(
    val enabled: Boolean = false,
    val audioSessionId: Int = 0,
    val selectedPresetIndex: Int = 0,
    val presetNames: List<String> = listOf(
        "Flat",
        "Spotify Emerald Bass",
        "Acoustic Warmth",
        "Electronic Pulse",
        "Vocal Clarity",
        "Rock Arena",
        "Late Night Lounge"
    ),
    val bands: List<EqualizerBand> = defaultBands(),
    val bassBoostStrength: Int = 0,
    val virtualizerStrength: Int = 0
) {
    companion object {
        fun defaultBands(): List<EqualizerBand> = listOf(
            EqualizerBand(index = 0, centerFreqHz = 60, minLevelMb = -1500, maxLevelMb = 1500, currentLevelMb = 0),
            EqualizerBand(index = 1, centerFreqHz = 230, minLevelMb = -1500, maxLevelMb = 1500, currentLevelMb = 0),
            EqualizerBand(index = 2, centerFreqHz = 910, minLevelMb = -1500, maxLevelMb = 1500, currentLevelMb = 0),
            EqualizerBand(index = 3, centerFreqHz = 3600, minLevelMb = -1500, maxLevelMb = 1500, currentLevelMb = 0),
            EqualizerBand(index = 4, centerFreqHz = 14000, minLevelMb = -1500, maxLevelMb = 1500, currentLevelMb = 0)
        )
    }
}
