package com.musical.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.musical.app.domain.model.PlaybackState
import com.musical.app.domain.model.Track
import com.musical.app.ui.components.CompactTrackThumbnail
import com.musical.app.ui.theme.EmeraldPrimary
import com.musical.app.ui.theme.TextPrimary
import com.musical.app.ui.theme.TextSecondary

@Composable
fun QueueSheet(
    playbackState: PlaybackState,
    onBack: () -> Unit,
    onSelectQueueTrack: (Track, List<Track>) -> Unit,
    onMoveQueueItem: (Int, Int) -> Unit,
    onRemoveQueueItem: (Int) -> Unit,
    onClearQueue: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(top = 16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Column {
                    Text(
                        text = "Playback Queue",
                        style = MaterialTheme.typography.headlineSmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "${playbackState.queue.size} tracks in queue",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }

            if (playbackState.queue.isNotEmpty()) {
                TextButton(onClick = onClearQueue) {
                    Icon(Icons.Rounded.DeleteSweep, contentDescription = null, tint = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear", color = EmeraldPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 12.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(
                items = playbackState.queue,
                key = { index, track -> "queue_${index}_${track.id}" }
            ) { index, track ->
                val isCurrent = index == playbackState.currentQueueIndex
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isCurrent) EmeraldPrimary.copy(alpha = 0.16f)
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable { onSelectQueueTrack(track, playbackState.queue) }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        CompactTrackThumbnail(
                            albumArtUri = track.albumArtUri,
                            titleSeed = track.title,
                            size = 42.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isCurrent) "▶ ${track.title}" else track.title,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (isCurrent) EmeraldPrimary else TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = track.artist,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { if (index > 0) onMoveQueueItem(index, index - 1) },
                            enabled = index > 0
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowUpward,
                                contentDescription = "Move Up",
                                tint = if (index > 0) TextSecondary else TextSecondary.copy(alpha = 0.25f)
                            )
                        }
                        IconButton(
                            onClick = {
                                if (index < playbackState.queue.lastIndex) {
                                    onMoveQueueItem(index, index + 1)
                                }
                            },
                            enabled = index < playbackState.queue.lastIndex
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowDownward,
                                contentDescription = "Move Down",
                                tint = if (index < playbackState.queue.lastIndex) TextSecondary
                                else TextSecondary.copy(alpha = 0.25f)
                            )
                        }
                        IconButton(onClick = { onRemoveQueueItem(index) }) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Remove from Queue",
                                tint = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
