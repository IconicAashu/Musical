package com.musical.app.data.local.scanner

import com.musical.app.domain.model.LrcLine
import java.io.File

object LrcParser {
    private val TIMESTAMP_REGEX = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val OFFSET_REGEX = Regex("""\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)

    /**
     * Parses standard and multi-timestamp LRC content into chronologically sorted [LrcLine] items.
     */
    fun parse(rawContent: String): List<LrcLine> {
        if (rawContent.isBlank()) return emptyList()
        var globalOffsetMs = 0L
        OFFSET_REGEX.find(rawContent)?.groupValues?.getOrNull(1)?.toLongOrNull()?.let {
            globalOffsetMs = it
        }

        val parsedLines = mutableListOf<LrcLine>()
        rawContent.lineSequence().forEach { rawLine ->
            val trimmed = rawLine.trim()
            if (trimmed.isEmpty()) return@forEach

            val matches = TIMESTAMP_REGEX.findAll(trimmed).toList()
            if (matches.isEmpty()) return@forEach

            val lyricText = trimmed.substring(matches.last().range.last + 1).trim()
            for (match in matches) {
                val minutes = match.groupValues[1].toLongOrNull() ?: 0L
                val seconds = match.groupValues[2].toLongOrNull() ?: 0L
                val fractionStr = match.groupValues.getOrNull(3).orEmpty()
                val millis = when (fractionStr.length) {
                    0 -> 0L
                    1 -> (fractionStr.toLongOrNull() ?: 0L) * 100L
                    2 -> (fractionStr.toLongOrNull() ?: 0L) * 10L
                    else -> fractionStr.take(3).toLongOrNull() ?: 0L
                }
                val timestampMs = (minutes * 60_000L + seconds * 1_000L + millis - globalOffsetMs)
                    .coerceAtLeast(0L)
                if (lyricText.isNotEmpty()) {
                    parsedLines.add(LrcLine(timestampMs = timestampMs, text = lyricText))
                }
            }
        }
        return parsedLines.sortedBy { it.timestampMs }
    }

    /**
     * Returns the index of the active lyric line for [positionMs], or -1 if before the first line.
     */
    fun findActiveLineIndex(lines: List<LrcLine>, positionMs: Long): Int {
        if (lines.isEmpty()) return -1
        var low = 0
        var high = lines.lastIndex
        var bestIndex = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (lines[mid].timestampMs <= positionMs) {
                bestIndex = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return bestIndex
    }

    /**
     * Attempts to locate a matching .lrc sidecar file on disk for an audio file path.
     */
    fun findSidecarLrcFile(audioFilePath: String): File? {
        if (audioFilePath.isBlank()) return null
        val audioFile = File(audioFilePath)
        val parentDir = audioFile.parentFile ?: return null
        val baseName = audioFile.nameWithoutExtension

        val candidates = listOf(
            File(parentDir, "$baseName.lrc"),
            File(parentDir, "$baseName.LRC"),
            File(File(parentDir, "Lyrics"), "$baseName.lrc"),
            File(File(parentDir, "lyrics"), "$baseName.lrc")
        )
        return candidates.firstOrNull { it.exists() && it.isFile && it.canRead() }
    }
}
