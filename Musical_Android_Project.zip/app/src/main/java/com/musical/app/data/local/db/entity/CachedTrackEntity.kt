package com.musical.app.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.musical.app.domain.model.Track

@Entity(tableName = "cached_tracks")
data class CachedTrackEntity(
    @PrimaryKey val id: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val artistId: Long,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val albumArtUri: String?,
    val filePath: String,
    val dateAddedSec: Long,
    val trackNumber: Int,
    val year: Int,
    val lrcFilePath: String?
) {
    fun toDomain(isFavourite: Boolean): Track = Track(
        id = id,
        uri = uri,
        title = title,
        artist = artist,
        artistId = artistId,
        album = album,
        albumId = albumId,
        durationMs = durationMs,
        albumArtUri = albumArtUri,
        filePath = filePath,
        dateAddedSec = dateAddedSec,
        trackNumber = trackNumber,
        year = year,
        isFavourite = isFavourite,
        lrcFilePath = lrcFilePath
    )

    companion object {
        fun fromDomain(track: Track): CachedTrackEntity = CachedTrackEntity(
            id = track.id,
            uri = track.uri,
            title = track.title,
            artist = track.artist,
            artistId = track.artistId,
            album = track.album,
            albumId = track.albumId,
            durationMs = track.durationMs,
            albumArtUri = track.albumArtUri,
            filePath = track.filePath,
            dateAddedSec = track.dateAddedSec,
            trackNumber = track.trackNumber,
            year = track.year,
            lrcFilePath = track.lrcFilePath
        )
    }
}
