package com.musical.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.musical.app.domain.model.Track
import com.musical.app.ui.components.TrackRowItem
import com.musical.app.ui.theme.AmoledBlack
import com.musical.app.ui.theme.EmeraldPrimary
import com.musical.app.ui.theme.TextPrimary
import com.musical.app.ui.theme.TextSecondary
import com.musical.app.ui.viewmodel.MusicalUiState
import com.musical.app.ui.viewmodel.SearchFilter

@Composable
fun SearchScreen(
    uiState: MusicalUiState,
    onQueryChange: (String) -> Unit,
    onFilterChange: (SearchFilter) -> Unit,
    onPlayTrack: (Track, List<Track>) -> Unit,
    onToggleFavourite: (Long) -> Unit,
    onPlayNext: (Track) -> Unit,
    onAddToQueue: (Track) -> Unit,
    onAddToPlaylist: (Long, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(top = 16.dp)
    ) {
        Text(
            text = "Search",
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = onQueryChange,
            placeholder = {
                Text("Songs, artists, albums, or playlists...", color = TextSecondary)
            },
            leadingIcon = {
                Icon(Icons.Rounded.Search, contentDescription = null, tint = EmeraldPrimary)
            },
            trailingIcon = {
                if (uiState.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Rounded.Clear, contentDescription = "Clear", tint = TextSecondary)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = EmeraldPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(SearchFilter.entries) { filter ->
                val selected = uiState.searchFilter == filter
                FilterChip(
                    selected = selected,
                    onClick = { onFilterChange(filter) },
                    label = {
                        Text(
                            text = filter.name.lowercase().replaceFirstChar { it.uppercase() },
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldPrimary,
                        selectedLabelColor = AmoledBlack,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        labelColor = TextPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 140.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (uiState.searchQuery.isBlank()) {
                item {
                    Text(
                        text = "Browse Local Moods & Categories",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BrowseCategoryCard(
                                title = "Studio Masters",
                                colorStart = Color(0xFF1DB954),
                                colorEnd = Color(0xFF0B4F24),
                                onClick = { onQueryChange("Studio") },
                                modifier = Modifier.weight(1f)
                            )
                            BrowseCategoryCard(
                                title = "Synth & Electronic",
                                colorStart = Color(0xFF7E57C2),
                                colorEnd = Color(0xFF311B92),
                                onClick = { onQueryChange("Synth") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BrowseCategoryCard(
                                title = "AMOLED Sessions",
                                colorStart = Color(0xFF00ACC1),
                                colorEnd = Color(0xFF004D40),
                                onClick = { onQueryChange("AMOLED") },
                                modifier = Modifier.weight(1f)
                            )
                            BrowseCategoryCard(
                                title = "All Local Audio",
                                colorStart = Color(0xFFEC407A),
                                colorEnd = Color(0xFF880E4F),
                                onClick = { onFilterChange(SearchFilter.SONGS) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(18.dp))
                }
            }

            if (uiState.searchFilter == SearchFilter.ALL || uiState.searchFilter == SearchFilter.SONGS) {
                item {
                    Text(
                        text = "Songs (${uiState.filteredTracks.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = EmeraldPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
                items(uiState.filteredTracks, key = { "search_track_${it.id}" }) { track ->
                    val isCurrent = uiState.playbackState.currentTrack?.id == track.id
                    TrackRowItem(
                        track = track,
                        isCurrentTrack = isCurrent,
                        isPlaying = isCurrent && uiState.playbackState.isPlaying,
                        playlists = uiState.playlists,
                        onTrackClick = { onPlayTrack(track, uiState.filteredTracks) },
                        onToggleFavourite = { onToggleFavourite(track.id) },
                        onPlayNext = { onPlayNext(track) },
                        onAddToQueue = { onAddToQueue(track) },
                        onAddToPlaylist = { playlistId -> onAddToPlaylist(playlistId, track.id) },
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }

            if (uiState.searchFilter == SearchFilter.ALL || uiState.searchFilter == SearchFilter.ARTISTS) {
                if (uiState.filteredArtists.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Artists (${uiState.filteredArtists.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = EmeraldPrimary,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                    items(uiState.filteredArtists, key = { "search_artist_${it.name}" }) { artist ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    artist.tracks.firstOrNull()?.let { first ->
                                        onPlayTrack(first, artist.tracks)
                                    }
                                }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Column {
                                Text(artist.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                Text(
                                    "${artist.trackCount} songs • ${artist.albumCount} albums",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                            Text("Play", style = MaterialTheme.typography.labelLarge, color = EmeraldPrimary)
                        }
                    }
                }
            }

            if (uiState.searchFilter == SearchFilter.ALL || uiState.searchFilter == SearchFilter.ALBUMS) {
                if (uiState.filteredAlbums.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Albums (${uiState.filteredAlbums.size})",
                            style = MaterialTheme.typography.titleMedium,
                            color = EmeraldPrimary,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                    items(uiState.filteredAlbums, key = { "search_album_${it.id}_${it.title}" }) { album ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    album.tracks.firstOrNull()?.let { first ->
                                        onPlayTrack(first, album.tracks)
                                    }
                                }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Column {
                                Text(album.title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                Text(
                                    "${album.artist} • ${album.trackCount} tracks",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                            Text("Play", style = MaterialTheme.typography.labelLarge, color = EmeraldPrimary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BrowseCategoryCard(
    title: String,
    colorStart: Color,
    colorEnd: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.BottomStart,
        modifier = modifier
            .height(82.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(colorStart, colorEnd)))
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary
        )
    }
}
