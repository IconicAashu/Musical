package com.musical.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.musical.app.data.local.scanner.LrcParser
import com.musical.app.domain.model.Album
import com.musical.app.domain.model.Artist
import com.musical.app.domain.model.EqualizerState
import com.musical.app.domain.model.LrcLine
import com.musical.app.domain.model.PlaybackState
import com.musical.app.domain.model.Playlist
import com.musical.app.domain.model.Track
import com.musical.app.domain.repository.MusicRepository
import com.musical.app.playback.PlaybackController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SearchFilter {
    ALL, SONGS, ARTISTS, ALBUMS, PLAYLISTS
}

enum class LibrarySortOrder(val label: String) {
    TITLE("Title A-Z"),
    ARTIST("Artist"),
    RECENTLY_ADDED("Date Added"),
    DURATION("Duration")
}

data class MusicalUiState(
    val allTracks: List<Track> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val favouriteTracks: List<Track> = emptyList(),
    val recentlyPlayed: List<Track> = emptyList(),
    val searchQuery: String = "",
    val searchFilter: SearchFilter = SearchFilter.ALL,
    val sortOrder: LibrarySortOrder = LibrarySortOrder.TITLE,
    val isScanning: Boolean = false,
    val isAmoledTheme: Boolean = true,
    val playbackState: PlaybackState = PlaybackState(),
    val equalizerState: EqualizerState = EqualizerState(),
    val currentLyrics: List<LrcLine> = emptyList(),
    val activeLyricIndex: Int = -1
) {
    val sortedTracks: List<Track>
        get() = when (sortOrder) {
            LibrarySortOrder.TITLE -> allTracks.sortedBy { it.title.lowercase() }
            LibrarySortOrder.ARTIST -> allTracks.sortedBy { it.artist.lowercase() }
            LibrarySortOrder.RECENTLY_ADDED -> allTracks.sortedByDescending { it.dateAddedSec }
            LibrarySortOrder.DURATION -> allTracks.sortedByDescending { it.durationMs }
        }

    val filteredTracks: List<Track>
        get() {
            val q = searchQuery.trim().lowercase()
            if (q.isEmpty()) return sortedTracks
            return sortedTracks.filter {
                it.title.lowercase().contains(q) ||
                    it.artist.lowercase().contains(q) ||
                    it.album.lowercase().contains(q)
            }
        }

    val filteredArtists: List<Artist>
        get() {
            val q = searchQuery.trim().lowercase()
            if (q.isEmpty()) return artists
            return artists.filter { it.name.lowercase().contains(q) }
        }

    val filteredAlbums: List<Album>
        get() {
            val q = searchQuery.trim().lowercase()
            if (q.isEmpty()) return albums
            return albums.filter {
                it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
            }
        }

    val filteredPlaylists: List<Playlist>
        get() {
            val q = searchQuery.trim().lowercase()
            if (q.isEmpty()) return playlists
            return playlists.filter {
                it.name.lowercase().contains(q) || it.description.lowercase().contains(q)
            }
        }
}

class MusicalViewModel(
    private val repository: MusicRepository,
    private val playbackController: PlaybackController
) : ViewModel() {

    private val searchQueryFlow = MutableStateFlow("")
    private val searchFilterFlow = MutableStateFlow(SearchFilter.ALL)
    private val sortOrderFlow = MutableStateFlow(LibrarySortOrder.TITLE)
    private val isScanningFlow = MutableStateFlow(false)
    private val currentLyricsFlow = MutableStateFlow<List<LrcLine>>(emptyList())
    private var loadedLyricsTrackId: Long = -1L

    private data class CoreDataBundle(
        val tracks: List<Track>,
        val favourites: List<Track>,
        val recent: List<Track>,
        val playlists: List<Playlist>,
        val isAmoled: Boolean
    )

    private val coreDataFlow = combine(
        repository.tracksFlow,
        repository.favouriteTracksFlow,
        repository.recentlyPlayedFlow,
        repository.playlistsFlow,
        repository.isAmoledThemeFlow
    ) { tracks, favourites, recent, playlists, isAmoled ->
        CoreDataBundle(tracks, favourites, recent, playlists, isAmoled)
    }

    private data class FilterUiBundle(
        val query: String,
        val filter: SearchFilter,
        val sort: LibrarySortOrder,
        val isScanning: Boolean,
        val lyrics: List<LrcLine>
    )

    private val filterUiFlow = combine(
        searchQueryFlow,
        searchFilterFlow,
        sortOrderFlow,
        isScanningFlow,
        currentLyricsFlow
    ) { query, filter, sort, scanning, lyrics ->
        FilterUiBundle(query, filter, sort, scanning, lyrics)
    }

    val uiState: StateFlow<MusicalUiState> = combine(
        coreDataFlow,
        filterUiFlow,
        playbackController.playbackState,
        playbackController.equalizerController.state
    ) { core, filterUi, playback, eqState ->
        playbackController.registerTracks(core.tracks)

        val derivedAlbums = core.tracks
            .groupBy { "${it.albumId}_${it.album.lowercase()}" }
            .map { (_, albumTracks) ->
                val first = albumTracks.first()
                Album(
                    id = first.albumId,
                    title = first.album,
                    artist = first.artist,
                    artistId = first.artistId,
                    albumArtUri = albumTracks.firstOrNull { !it.albumArtUri.isNullOrBlank() }?.albumArtUri,
                    year = first.year,
                    tracks = albumTracks.sortedBy { it.trackNumber }
                )
            }
            .sortedBy { it.title.lowercase() }

        val derivedArtists = core.tracks
            .groupBy { it.artist.lowercase() }
            .map { (_, artistTracks) ->
                val first = artistTracks.first()
                val artistAlbums = derivedAlbums.filter {
                    it.artist.equals(first.artist, ignoreCase = true)
                }
                Artist(
                    id = first.artistId,
                    name = first.artist,
                    tracks = artistTracks,
                    albums = artistAlbums
                )
            }
            .sortedBy { it.name.lowercase() }

        val activeLineIdx = LrcParser.findActiveLineIndex(filterUi.lyrics, playback.positionMs)

        MusicalUiState(
            allTracks = core.tracks,
            albums = derivedAlbums,
            artists = derivedArtists,
            playlists = core.playlists,
            favouriteTracks = core.favourites,
            recentlyPlayed = core.recent,
            searchQuery = filterUi.query,
            searchFilter = filterUi.filter,
            sortOrder = filterUi.sort,
            isScanning = filterUi.isScanning,
            isAmoledTheme = core.isAmoled,
            playbackState = playback,
            equalizerState = eqState,
            currentLyrics = filterUi.lyrics,
            activeLyricIndex = activeLineIdx
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = MusicalUiState()
    )

    init {
        scanLocalMusic()
        viewModelScope.launch {
            playbackController.playbackState.collect { playback ->
                val currentTrack = playback.currentTrack
                if (currentTrack != null && currentTrack.id != loadedLyricsTrackId) {
                    loadedLyricsTrackId = currentTrack.id
                    currentLyricsFlow.value = repository.loadLyricsForTrack(currentTrack)
                } else if (currentTrack == null) {
                    loadedLyricsTrackId = -1L
                    currentLyricsFlow.value = emptyList()
                }
            }
        }
    }

    fun scanLocalMusic() {
        viewModelScope.launch {
            isScanningFlow.value = true
            val scanned = repository.scanDeviceMusic()
            playbackController.registerTracks(scanned)
            isScanningFlow.value = false
        }
    }

    fun updateSearchQuery(query: String) {
        searchQueryFlow.value = query
    }

    fun updateSearchFilter(filter: SearchFilter) {
        searchFilterFlow.value = filter
    }

    fun updateSortOrder(order: LibrarySortOrder) {
        sortOrderFlow.value = order
    }

    fun playTrack(track: Track, contextQueue: List<Track> = emptyList()) {
        val queue = if (contextQueue.isNotEmpty()) contextQueue else uiState.value.sortedTracks.ifEmpty { listOf(track) }
        val index = queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        playbackController.playTracks(queue, index)
    }

    fun playCollection(tracks: List<Track>, shuffle: Boolean = false) {
        if (tracks.isEmpty()) return
        val ordered = if (shuffle) tracks.shuffled() else tracks
        playbackController.playTracks(ordered, 0)
    }

    fun togglePlayPause() = playbackController.togglePlayPause()
    fun seekTo(positionMs: Long) = playbackController.seekTo(positionMs)
    fun skipNext() = playbackController.skipNext()
    fun skipPrevious() = playbackController.skipPrevious()
    fun toggleShuffle() = playbackController.toggleShuffle()
    fun cycleRepeatMode() = playbackController.cycleRepeatMode()

    fun addToQueue(track: Track) = playbackController.addToQueue(track)
    fun playNextInQueue(track: Track) = playbackController.playNextInQueue(track)
    fun removeFromQueue(index: Int) = playbackController.removeFromQueue(index)
    fun moveQueueItem(fromIndex: Int, toIndex: Int) = playbackController.moveQueueItem(fromIndex, toIndex)
    fun clearQueue() = playbackController.clearQueue()

    fun toggleFavourite(trackId: Long) {
        viewModelScope.launch {
            repository.toggleFavourite(trackId)
        }
    }

    fun createPlaylist(name: String, description: String) {
        viewModelScope.launch {
            repository.createPlaylist(name, description)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun addTrackToPlaylist(playlistId: Long, trackId: Long) {
        viewModelScope.launch {
            repository.addTrackToPlaylist(playlistId, trackId)
        }
    }

    fun removeTrackFromPlaylist(playlistId: Long, trackId: Long) {
        viewModelScope.launch {
            repository.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    fun setEqualizerEnabled(enabled: Boolean) {
        playbackController.equalizerController.setEnabled(enabled)
    }

    fun setEqualizerBandLevel(bandIndex: Int, levelMb: Int) {
        playbackController.equalizerController.setBandLevel(bandIndex, levelMb)
    }

    fun selectEqualizerPreset(presetIndex: Int) {
        playbackController.equalizerController.selectPreset(presetIndex)
    }

    fun setBassBoostStrength(strength: Int) {
        playbackController.equalizerController.setBassBoostStrength(strength)
    }

    fun setVirtualizerStrength(strength: Int) {
        playbackController.equalizerController.setVirtualizerStrength(strength)
    }

    fun startSleepTimer(minutes: Int) {
        playbackController.sleepTimerManager.startTimer(minutes)
    }

    fun setStopAtEndOfCurrentTrack(enabled: Boolean) {
        playbackController.sleepTimerManager.setStopAtEndOfCurrentTrack(enabled)
    }

    fun cancelSleepTimer() {
        playbackController.sleepTimerManager.cancelTimer()
    }

    fun toggleAmoledTheme() {
        viewModelScope.launch {
            repository.setAmoledTheme(!uiState.value.isAmoledTheme)
        }
    }

    fun saveCustomLrcLyrics(rawLrcContent: String) {
        val currentTrack = uiState.value.playbackState.currentTrack ?: return
        viewModelScope.launch {
            val parsed = repository.saveCustomLyricsForTrack(currentTrack.id, rawLrcContent)
            currentLyricsFlow.value = parsed
        }
    }

    override fun onCleared() {
        super.onCleared()
        playbackController.release()
    }

    class Factory(
        private val repository: MusicRepository,
        private val playbackController: PlaybackController
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MusicalViewModel(repository, playbackController) as T
        }
    }
}
