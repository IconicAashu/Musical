package com.musical.app.domain.model

data class Album(
    val id: Long,
    val title: String,
    val artist: String,
    val artistId: Long,
    val albumArtUri: String?,
    val year: Int,
    val tracks: List<Track>
) {
    val trackCount: Int get() = tracks.size
    val totalDurationMs: Long get() = tracks.sumOf { it.durationMs }
}
