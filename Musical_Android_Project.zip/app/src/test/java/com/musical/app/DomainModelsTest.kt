package com.musical.app

import com.musical.app.domain.model.EqualizerState
import com.musical.app.domain.model.PlaybackState
import com.musical.app.domain.model.Track
import org.junit.Assert.assertEquals
import org.junit.Test

class DomainModelsTest {

    @Test
    fun trackFormattedDurationCalculatesMinutesAndSeconds() {
        val track = Track(
            id = 1L,
            uri = "content://media/external/audio/media/1",
            title = "Midnight Pulse",
            artist = "Nova",
            artistId = 10L,
            album = "AMOLED",
            albumId = 20L,
            durationMs = 215_000L,
            albumArtUri = null,
            filePath = "/storage/emulated/0/Music/MidnightPulse.mp3",
            dateAddedSec = 1700000000L
        )
        assertEquals("3:35", track.formattedDuration)
    }

    @Test
    fun playbackProgressFractionHandlesZeroAndClamping() {
        val idleState = PlaybackState(positionMs = 0L, durationMs = 0L)
        assertEquals(0f, idleState.progressFraction, 0.0001f)

        val midState = PlaybackState(positionMs = 30_000L, durationMs = 120_000L)
        assertEquals(0.25f, midState.progressFraction, 0.0001f)
    }

    @Test
    fun equalizerDefaultBandsProvideFiveStandardFrequencies() {
        val bands = EqualizerState.defaultBands()
        assertEquals(5, bands.size)
        assertEquals("60Hz", bands[0].formattedFrequency)
        assertEquals("3.6kHz", bands[3].formattedFrequency)
        assertEquals("14kHz", bands[4].formattedFrequency)
    }
}
