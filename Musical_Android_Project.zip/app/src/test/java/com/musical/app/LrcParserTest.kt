package com.musical.app

import com.musical.app.data.local.scanner.LrcParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LrcParserTest {

    @Test
    fun parseStandardAndMultiTimestampLrcLines() {
        val sampleLrc = """
            [ti:Emerald Horizons]
            [ar:Musical Synth Ensemble]
            [offset:100]
            [00:01.50]Opening synth chord
            [00:05.00][00:15.00]Repeated chorus hook
            [00:10.250]Bridge melody line
        """.trimIndent()

        val parsed = LrcParser.parse(sampleLrc)
        assertEquals(4, parsed.size)
        // With +100ms offset subtracted:
        assertEquals(1400L, parsed[0].timestampMs)
        assertEquals("Opening synth chord", parsed[0].text)

        assertEquals(4900L, parsed[1].timestampMs)
        assertEquals("Repeated chorus hook", parsed[1].text)

        assertEquals(10150L, parsed[2].timestampMs)
        assertEquals("Bridge melody line", parsed[2].text)

        assertEquals(14900L, parsed[3].timestampMs)
        assertEquals("Repeated chorus hook", parsed[3].text)
    }

    @Test
    fun findActiveLineIndexBinarySearchWorksCorrectly() {
        val lines = LrcParser.parse(
            """
            [00:02.00]Line Zero
            [00:06.00]Line One
            [00:12.00]Line Two
            """.trimIndent()
        )
        assertEquals(-1, LrcParser.findActiveLineIndex(lines, 500L))
        assertEquals(0, LrcParser.findActiveLineIndex(lines, 2000L))
        assertEquals(0, LrcParser.findActiveLineIndex(lines, 5999L))
        assertEquals(1, LrcParser.findActiveLineIndex(lines, 6000L))
        assertEquals(2, LrcParser.findActiveLineIndex(lines, 25000L))
        assertTrue(LrcParser.parse("").isEmpty())
    }
}
