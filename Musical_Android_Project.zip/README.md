# Musical — Spotify-Inspired AMOLED Android Music Player

**Musical** is a native Android audio player written in **Kotlin** using **Jetpack Compose (Material 3)**, **AndroidX Media3 (ExoPlayer + MediaSessionService)**, **Room Database**, and **MVVM + Clean Architecture**.

## Architecture & Module Layout

- **`domain/model/`**: Immutable models (`Track`, `Album`, `Artist`, `Playlist`, `LrcLine`, `EqualizerState`, `EqualizerBand`, `PlaybackState`, `RepeatMode`).
- **`domain/repository/`**: `MusicRepository` contract for local audio scanning, favourites, recently played, playlists, and synchronized LRC lyrics.
- **`data/local/db/`**: Room database (`MusicalDatabase`, `MusicDao`) and entities (`CachedTrackEntity`, `FavouriteTrackEntity`, `RecentPlayEntity`, `PlaylistEntity`, `PlaylistTrackCrossRef`, `CustomLrcEntity`).
- **`data/local/scanner/`**:
  - `LocalAudioScanner`: Queries `MediaStore.Audio.Media` for local MP3, FLAC, WAV, OGG, and M4A files, resolves album artwork URIs, discovers sidecar `.lrc` files, and unpacks the built-in studio master track (`demo_emerald_horizons.wav` + `demo_emerald_horizons.lrc`).
  - `LrcParser`: Parses standard and multi-timestamp `.lrc` lyrics (`[mm:ss.xx]`, `[offset:+/-ms]`) and performs binary search for real-time lyric highlighting.
- **`playback/`**:
  - `MusicalPlaybackService`: Foreground `MediaSessionService` with `ExoPlayer`, `AudioAttributes`, noisy-audio handling, wake lock, and `DefaultMediaNotificationProvider`.
  - `AudioEqualizerController`: Hardware `Equalizer`, `BassBoost`, and `Virtualizer` bound to the active ExoPlayer `audioSessionId` with 7 acoustic presets and 5-band dB sliders.
  - `SleepTimerManager`: Coroutine countdown timer (`5m`–`90m`) plus "Stop at end of current track".
  - `PlaybackController`: Bridges `MediaController` state, queue management (play next, add, reorder, remove, clear), shuffle, and repeat modes (`OFF`, `ALL`, `ONE`).
- **`ui/`**:
  - `theme/`: Spotify Emerald (`#1DB954`) + pure AMOLED Black (`#000000`) / Spotify Dark (`#121212`) dynamic theme switcher.
  - `components/`: `AnimatedAlbumArtwork` (rotating vinyl platter with emerald radial glow), `MiniPlayerBar`, `TrackRowItem`, `SleepTimerDialog`.
  - `screens/`: `HomeScreen`, `SearchScreen`, `LibraryScreen`, `ArtistsAlbumsScreen`, `NowPlayingScreen`, `QueueSheet`, `LyricsScreen`, `EqualizerScreen`, `MusicalAppRoot`.

## Building the APK

### Prerequisites
1. **JDK 17** (`JAVA_HOME` pointing to OpenJDK 17)
2. **Android SDK Platform 34** (`platforms;android-34`) & **Build Tools 34.0.0** (`build-tools;34.0.0`)
3. **Gradle 8.7** (or Android Studio Jellyfish / Koala or newer)

### Commands
```bash
# Run unit tests
./gradlew testDebugUnitTest

# Build the Debug APK
./gradlew assembleDebug
```
The compiled debug APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`
